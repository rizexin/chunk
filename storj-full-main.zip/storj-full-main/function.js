import { chromium, request } from 'playwright'
import net from 'net'
import dns from 'dns'
import { SocksProxyAgent } from 'socks-proxy-agent'
import pojectnamegenerator from 'project-name-generator'
import { default as ConfigParser } from 'configparser'
import { faker, tr } from '@faker-js/faker'
import axios from 'axios'
import path from 'path'
import fs from 'fs'
import chalk, { backgroundColorNames } from 'chalk'
import * as cheerio from 'cheerio'
import { Performance } from 'perf_hooks'
import { HttpsProxyAgent as HttpProxyAgent } from 'https-proxy-agent'
const __dirname = path.dirname(new URL(import.meta.url).pathname)

export function isIpAddress(value) {
  return net.isIP(value) !== 0
}

export async function submitStorj(config, data) {
  let email = null
  try {
    const submitUrl = new URL(`/storj/register`, `${config.baseUrl}`)
    const apiKey = config.chiaChunkApiKey
    submitUrl.searchParams.append('apiKey', apiKey)
    const submit = await axios.post(submitUrl.toString(), data)
    email = data.email
    if (submit.data.success == true) {
      verboseLog('INFO', `Success Submit ${email} to database`)
    }
  } catch (e) {
    verboseLog('ERROR', `Error submitting ${email} to database`)
  }
}
export async function verboseLog(type, message) {
  const date = new Date()
  const time = date.toLocaleTimeString()
  let color = chalk.white
  if (type == 'ERROR') {
    color = chalk.red
  } else if (type == 'SUCCESS') {
    color = chalk.green
  } else if (type == 'NOTICE') {
    color = chalk.blue
  } else {
    color = chalk.white
  }
  console.log(color(`${time} [${type}] ${message}`))
}

export function randTimeout(min, max) {
  return Math.floor(Math.random() * (max - min + 1) + min)
}

export async function changeIp(proxy) {
  let proxyAgent
  const { protocol } = new URL(proxy.proxyFull)
  if (protocol == 'socks5:') {
    proxyAgent = new SocksProxyAgent(proxy.proxyFull)
  } else if (protocol == 'http:') {
    proxyAgent = new HttpProxyAgent(proxy.proxyFull)
  }
  const url = proxy.changeIpUrl

  if (proxy.changeIpUrl == null || proxy.changeIpUrl == '') {
    return 0
  }
  const checkIpUrl = 'https://ipinfo.io'
  let oldIp = {}
  oldIp.data = ''
  try {
    oldIp = await axios
      .get(checkIpUrl, {
        httpAgent: proxyAgent,
        httpsAgent: proxyAgent
      })
      .then((res) => {
        return res
      })
    verboseLog('INFO', `Old IP: ${oldIp.data.ip}`)
  } catch (e) {
    verboseLog('ERROR', `Error getting old IP`)
  }
  for (let i = 0; i < 5; i++) {
    try {
      const changeip = await axios.get(url)
      verboseLog('INFO', `Change IP`)
      break
    } catch (e) {
      verboseLog('ERROR', `Error changing IP`)
      verboseLog('ERROR', e)
      await sleep(60000)
    }
  }

  let newIp = null
  let maxTry = 5
  let tryCount = 0
  for (tryCount = 0; tryCount < maxTry; tryCount++) {
    try {
      newIp = await axios
        .get(checkIpUrl, {
          httpAgent: proxyAgent,
          httpsAgent: proxyAgent
        })
        .then((res) => {
          return res
        })
      if (newIp.data == oldIp.data) {
        await sleep(1000)
        continue
      }
      verboseLog('INFO', `New IP: ${newIp.data.ip}`)
      return 0
    } catch (e) {
      verboseLog('ERROR', `Error getting new IP`)
      await sleep(60000)
    }
  }
  return 1
}

export async function parseConfig() {
  const config = new ConfigParser()
  config.read(path.join(__dirname, 'config.conf'))
  const noCaptchaAiApiKey = config.get('main', 'noCaptchaAiApiKey')
  const capSolverApiKey = config.get('main', 'capSolverApiKey')
  const captchaAiApiKey = config.get('main', 'captchaAiApiKey')
  const antiCaptchaApiKey = config.get('main', 'antiCaptchaApiKey')
  const twoCaptchaApiKey = config.get('main', 'twoCaptchaApiKey')
  let separateProxy = config.get('main', 'separateProxy')
  //convert string to boolean
  separateProxy = separateProxy == 'true'
  const skip = config.get('main', 'skip')
  const siteKey = config.get('main', 'siteKey')
  const baseUrl = config.get('main', 'baseUrl')
  const websiteUrl = config.get('main', 'websiteUrl')
  const chiaChunkApiKey = config.get('main', 'chiaChunkApiKey')
  const useSolver = config.get('main', 'useSolver')
  const solverArray = {
    noCaptchaAiApiKey,
    capSolverApiKey,
    captchaAiApiKey,
    antiCaptchaApiKey,
    twoCaptchaApiKey
  }
  const main = Object.keys(solverArray).reduce(
    (acc, key) => {
      if (solverArray[key] != '') {
        acc[key] = solverArray[key]
      }
      return acc
    },
    {
      separateProxy,
      siteKey,
      baseUrl,
      chiaChunkApiKey,
      websiteUrl,
      useSolver,
      skip
    }
  )
  return main
}

export async function parseDataImpulse() {
  try {
    const config = new ConfigParser()
    config.read(path.join(__dirname, 'config.conf'))
    const user = config.get('dataImpulse', 'user')
    const pass = config.get('dataImpulse', 'pass')
    const countrySet = config.get('dataImpulse', 'countrySet')
    //set static proxy type
    const proxyType = 'http'
    // set static proxy host
    const proxyHost = '148.251.5.30'
    // set random proxy port from 10000 to 10100
    const proxyPort = Math.floor(Math.random() * (10100 - 10000 + 1) + 10000)
    //set random session id string with 8 character
    const sessionId = Math.random().toString(36).substring(2, 10)
    let proxyFullSticky = new URL(`${proxyType}://${proxyHost}`)
    let proxyFullRotate = new URL(`${proxyType}://${proxyHost}`)
    let userString = `${user}`
    if (countrySet) {
      userString += `__cr.${countrySet}`
    }
    let userStringSticky = userString + `;__sessid.${sessionId}`
    proxyFullSticky.port = proxyPort
    proxyFullRotate.port = 824
    proxyFullSticky.username = userStringSticky
    proxyFullRotate.username = userString
    proxyFullSticky.password = pass
    proxyFullRotate.password = pass
    proxyFullSticky = proxyFullSticky.toString()
    proxyFullRotate = proxyFullRotate.toString()
    if (proxyFullSticky.endsWith('/')) {
      proxyFullSticky = proxyFullSticky.slice(0, -1)
    }
    if (proxyFullRotate.endsWith('/')) {
      proxyFullRotate = proxyFullRotate.slice(0, -1)
    }
    const proxy = new HttpProxyAgent(proxyFullSticky)
    const url = 'https://ipinfo.io'
    const ipDetail = await axios
      .get(url, {
        httpAgent: proxy,
        httpsAgent: proxy
      })
      .then((res) => {
        return res.data
      })
    const result = {
      user,
      pass,
      countrySet,
      proxyType,
      proxyHost,
      proxyPort,
      sessionId,
      proxyFullSticky,
      proxyFullRotate,
      ipDetail: ipDetail
    }
    return result
  } catch (e) {
    verboseLog('ERROR', `Error parsing DataImpulse`)
  }
}

export async function parseProxy() {
  try {
    const config = new ConfigParser()
    config.read(path.join(__dirname, 'config.conf'))
    const proxyType = config.get('proxy', 'proxyType')
    const proxy = config.get('proxy', 'proxy')
    const proxyHost = proxy.split(':')[0]
    const proxyPort = proxy.split(':')[1]
    const changeIpUrl = config.get('proxy', 'changeIpUrl')
    const otherProxy = config.get('proxy', 'otherProxy')

    const user =
      config.get('proxy', 'user') === '' ? null : config.get('proxy', 'user')
    const pass =
      config.get('proxy', 'pass') === '' ? null : config.get('proxy', 'pass')

    let proxyFull = `${proxyType}://`
    let result = {}
    if (user != null && pass != null) {
      proxyFull += `${user}:${pass}@`
      result.user = user
      result.pass = pass
    }
    proxyFull += `${proxyHost}:${proxyPort}`

    proxyFull = proxyFull.toString()
    //remove any %22 from proxyFull
    proxyFull = proxyFull.replace(/%22/g, '')
    //replace %3B with ;
    proxyFull = proxyFull.replace(/%3B/g, ';')
    if (proxyFull.endsWith('/')) {
      proxyFull = proxyFull.slice(0, -1)
    }

    result = {
      ...result,
      proxyType,
      proxyHost,
      proxyPort,
      proxyFull,
      changeIpUrl,
      otherProxy
    }

    return result
  } catch (e) {
    verboseLog('ERROR', `Error parsing proxy`)
    verboseLog('ERROR', e)
  }
}

export async function generateData() {
  try {
    const { generate } = pojectnamegenerator
    const projectName = generate({ number: true }).dashed
    const password = faker.internet.password({ length: 12 })
    const userAgent = faker.internet.userAgent()
    const accessName = generate({
      words: 2,
      alliterative: true,
      number: true
    }).spaced
    const fullName = faker.person.fullName()
    return { projectName, accessName, fullName, password, userAgent }
  } catch (e) {
    verboseLog('ERROR', `Error generating data`)
  }
}

export async function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms))
}

export async function getMailAddress(proxyFull) {
  let proxyAgent
  try {
    const { protocol } = new URL(proxyFull)
    if (protocol == 'socks5:') {
      proxyAgent = new SocksProxyAgent(proxyFull)
    } else if (protocol == 'http:') {
      proxyAgent = new HttpProxyAgent(proxyFull)
    }
    const mailUrl = 'https://generator.email/'

    const getMail = await axios.get(mailUrl, {
      httpAgent: proxyAgent,
      httpsAgent: proxyAgent
    })
    const mailAddress = getMail.data.match(
      /<b><span id="email_ch_text">([^<]+)<\/span><\/b>/
    )[1]
    const user = mailAddress.split('@')[0]
    const domain = mailAddress.split('@')[1]
    const domainExt = domain.split('.')[1]
    return mailAddress
  } catch (e) {
    verboseLog('ERROR', `Error getting mail address`)
    verboseLog('ERROR', e)
  }
}

export async function getConfirmUrl2(emailAddress, proxy, signUpdata) {
  const { protocol } = new URL(proxy.proxyFull)
  let proxyAgent = null
  if (protocol === 'socks5:') {
    proxyAgent = new SocksProxyAgent(proxy.proxyFull)
  } else if (protocol === 'http:') {
    proxyAgent = new HttpProxyAgent(proxy.proxyFull)
  }
  try {
    const user = emailAddress.split('@')[0]
    const domain = emailAddress.split('@')[1]
    const cookie =
      '_ga=GA1.2.747718287.1611551159; _gid=GA1.2.786119622.1615220663; ' +
      'embx=%5B%22dogeanjay00%40gxmer.com%22%2C%22ayamanjay%40bedul.net' +
      '%22%2C%22ngawurnajayy%40plitur.com%22%2C%222ionel.radu.9826%40coronagg.com' +
      '%22%2C%221ahmad.pop%40hustletussle.com%22%2C%22hmohame%40acmta.com' +
      '%22%2C%22qsmar%40ucombinator.com%22%2C%22zlimon.shuvo29%40furnitt.com' +
      '%22%2C%22odmsal1%40wikuiz.com%22%5D; _gat=1; ' +
      `surl=${domain}%2F${user}`
    const url = 'https://generator.email/inbox5/'
    const headers = {
      Cookie: cookie
    }
    let getConfirmUrl = null
    let confirmUrlLink = null
    for (let i = 0; i < 5; i++) {
      try {
        getConfirmUrl = await axios.get(url, {
          headers: headers,
          httpAgent: proxyAgent,
          httpsAgent: proxyAgent
        })
        try {
          confirmUrlLink = getConfirmUrl.data.match(
            /(https:\/\/eu1.storj.io\/activation\?[^"]+)/
          )[0]
        } catch (e) {}
        if (confirmUrlLink != null) {
          verboseLog(
            'INFO',
            `confirm link found for ${emailAddress} with 1 Signup`
          )
          return confirmUrlLink
        }
        if (signUpdata) {
          const { data, captchaResponse } = signUpdata
          await signUpStorj(data, emailAddress, proxy, captchaResponse)
        }

        const $ = cheerio.load(getConfirmUrl.data)
        // check if div with id id="email-table" exists using cheerio
        let emailTable = $('#email-table')
        if (emailTable.length > 0) {
          // get href from first a tag on email-table
          let mailUrl = emailTable.find('a').attr('href')
          mailUrl = new URL(mailUrl, url)
          mailUrl = mailUrl.toString()
          const browser = await chromium.launch({
            headless: false,
            proxy: { server: proxy.proxyFull },
            headers: headers
          })
          const page = await browser.newPage()
          await page.goto(mailUrl)
          //await page.waitForLoadState('networkidle')
          //look for the confirm url contain href with eu1.storj.io
          await sleep(1000)
          getConfirmUrl = await page.content()
          //parse the html and look for the confirm url contain href with eu1.storj.io and return the url
          confirmUrlLink = getConfirmUrl.match(
            /(https:\/\/eu1.storj.io\/activation\?[^"]+)/
          )[0]
          await page.close()
          await browser.close()
          if (confirmUrlLink != null) {
            verboseLog(
              'INFO',
              `confirm link found for ${emailAddress} with multiple Signup`
            )
            return confirmUrlLink
          }
          console.log(`retry`)
          await sleep(2000)
        }
      } catch (e) {
        console.log(e)
        await sleep(2000)
      }
    }
    if (confirmUrlLink) {
      return confirmUrlLink
    }
  } catch (e) {
    verboseLog('ERROR', `Error getting confirm url for ${emailAddress}`)
    console.log(e)
    return null
  }
}

export async function getConfirmUrl(emailAddress, proxy) {
  try {
    const proxyAgent = new SocksProxyAgent(proxy.proxyFull)
    const user = emailAddress.split('@')[0]
    const domain = emailAddress.split('@')[1]
    const cookie =
      '_ga=GA1.2.747718287.1611551159; _gid=GA1.2.786119622.1615220663; ' +
      'embx=%5B%22dogeanjay00%40gxmer.com%22%2C%22ayamanjay%40bedul.net' +
      '%22%2C%22ngawurnajayy%40plitur.com%22%2C%222ionel.radu.9826%40coronagg.com' +
      '%22%2C%221ahmad.pop%40hustletussle.com%22%2C%22hmohame%40acmta.com' +
      '%22%2C%22qsmar%40ucombinator.com%22%2C%22zlimon.shuvo29%40furnitt.com' +
      '%22%2C%22odmsal1%40wikuiz.com%22%5D; _gat=1; ' +
      `surl=${domain}%2F${user}`
    const url = 'https://generator.email/inbox5/'
    const headers = {
      Cookie: cookie
    }
    let getConfirmUrl = null
    let confirmUrlLink = null
    for (let i = 0; i < 5; i++) {
      try {
        if (confirmUrlLink != null && i > 0) {
          verboseLog('INFO', `confirm link found for ${emailAddress}`)
          return confirmUrlLink
        }
        if (confirmUrlLink != null) {
          return confirmUrlLink
        }
        await sleep(5000)
        getConfirmUrl = await axios.get(url, {
          headers: headers,
          httpAgent: proxyAgent,
          httpsAgent: proxyAgent
        })
        confirmUrlLink = getConfirmUrl.data.match(
          /(https:\/\/eu1.storj.io\/activation\?[^"]+)/
        )[0]
      } catch (e) {
        await sleep(2000)
      }
    }
    return confirmUrlLink
  } catch (e) {
    verboseLog('ERROR', `Error getting confirm url for ${emailAddress}`)
    console.log(e)
    return null
  }
}

export async function noCaptchaAiSolve(config, proxy) {
  try {
    const proxyAgent = new SocksProxyAgent(proxy.proxyFull)
    const apiKey = config.noCaptchaAiApiKey
    const siteKey = config.siteKey
    const websiteUrl = config.websiteUrl
    const siteHost = websiteUrl.split('/')[2]
    const noCaptchaAiUrl = 'https://token.nocaptchaai.com/token'
    async function getRqData(proxyAgent) {
      try {
        const rqUrl = new URL(`https://hcaptcha.com/checksiteconfig`)
        rqUrl.searchParams.append('v', '096d3a6')
        rqUrl.searchParams.append('host', siteHost)
        rqUrl.searchParams.append('sitekey', siteKey)
        rqUrl.searchParams.append('sc', '1')
        rqUrl.searchParams.append('swa', '1')
        rqUrl.searchParams.append('spst', '1')

        const rqData = await axios
          .get(rqUrl.toString(), {
            httpAgent: proxyAgent,
            httpsAgent: proxyAgent
          })
          .then((res) => {
            return res.data.c.req
          })
        return rqData
      } catch (e) {
        console.log({
          message: 'Error getting rqdata',
          error: e
        })
      }
    }
    const data = {
      url: websiteUrl,
      sitekey: siteKey,
      type: 'hcaptcha',
      proxy: {
        ip: proxy.proxyHost,
        port: proxy.proxyPort,
        type: proxy.proxyType
      }
    }
    if (proxy.user != null && proxy.pass != null) {
      data.proxy.username = proxy.user
      data.proxy.password = proxy.pass
    }
    const headers = {
      'Content-Type': 'application/json',
      apikey: apiKey
    }
    let taskUrl = null
    let maxTry = 5
    let tryCount = 0

    data.rqdata = await getRqData(proxyAgent)
    try {
      taskUrl = await axios
        .post(noCaptchaAiUrl, data, {
          headers: headers
        })
        .then((res) => {
          return res.data.url
        })
    } catch (e) {
      throw 'Error getting taskUrl'
    }
    if (taskUrl == null) {
      return null
    }
    tryCount++
    if (tryCount >= maxTry) {
      return null
    }
    await sleep(5000)

    let captchaResponse = null

    while (true) {
      captchaResponse = await axios.get(taskUrl, {
        headers: headers
      })
      if (captchaResponse.data.status == 'processing') {
        await sleep(5000)
      }
      if (captchaResponse.data.status == 'processed') {
        captchaResponse = captchaResponse.data.token
        break
      }
      if (captchaResponse.data.status == 'failed') {
        throw new Error('Error solving captcha')
      }
    }

    return captchaResponse
  } catch (e) {
    verboseLog('ERROR', `Error solving captcha`)
    return null
  }
}

export async function getTwoCaptchaCredit(config) {
  const url = 'https://api.2captcha.com/getBalance'
  const apiKey = config.twoCaptchaApiKey
  const data = {
    clientKey: apiKey
  }
  let balance
  try {
    axios.post(url, data).then((res) => {
      balance = res.data.balance
      return balance
    })
    return balance
  } catch (e) {
    verboseLog('ERROR', `Error getting 2captcha balance`)
    return null
  }
}

export async function twoCaptchaSolve(config, proxy, emailAddress) {
  const timerStart = performance.now()
  let { proxyHost, proxyPort, proxyType, user, pass } = proxy
  if (!isIpAddress(proxyHost)) {
    try {
      proxyHost = await dns.promises.lookup(proxyHost).then(
        (res) => {
          return res.address
        },
        (err) => {
          verboseLog('ERROR', `Error resolving proxy hostname`)
          return null
        }
      )
    } catch (e) {
      verboseLog('ERROR', `Error resolving proxy hostname`)
      return null
    }
  }
  const data = {
    clientKey: config.twoCaptchaApiKey,
    task: {
      type: 'HCaptchaTask',
      websiteURL: config.websiteUrl,
      websiteKey: config.siteKey,
      proxyType: proxyType,
      proxyAddress: proxyHost,
      proxyPort: proxyPort,
      proxyLogin: user,
      proxyPassword: pass
    }
  }
  const url = 'https://api.2captcha.com/createTask'
  const getTaskUrl = 'https://api.2captcha.com/getTaskResult'
  let taskId = null
  let captchaResponse = null
  try {
    const response = await axios.post(url, data)
    //force taskId to be number
    taskId = response.data.taskId
    taskId = Number(taskId)
    if (response.data.errorId != 0 || taskId == null) {
      verboseLog('ERROR', `${emailAddress} | Error getting taskId`)
      verboseLog('ERROR', response.data.errorDescription)
      return null
    }
    verboseLog('INFO', `${emailAddress} | Got taskId ${taskId}`)
    while (true) {
      captchaResponse = await axios.post(getTaskUrl, {
        clientKey: config.twoCaptchaApiKey,
        taskId: taskId
      })
      if (captchaResponse.data.errorId !== 0) {
        verboseLog('ERROR', `${emailAddress} | Error getting captcha response`)
        verboseLog('ERROR', captchaResponse.data.errorDescription)
        return null
      }
      if (
        captchaResponse.data.errorId == 0 &&
        captchaResponse.data.status !== 'ready'
      ) {
        await sleep(5000)
        continue
      }
      if (captchaResponse.data.status === 'ready') {
        captchaResponse = captchaResponse.data.solution.gRecaptchaResponse
        break
      }
    }
    const timerEnd = performance.now()
    const totalTime = Math.floor((timerEnd - timerStart) / 1000)
    const shortResponse =
      captchaResponse.slice(0, 8) + '...' + captchaResponse.slice(-8)
    verboseLog(
      'NOTICE',
      `${emailAddress} | Got captcha response ${shortResponse} in ${totalTime} seconds`
    )
    return captchaResponse
  } catch (e) {
    verboseLog('ERROR', `${emailAddress} Error getting captcha Response`)
    verboseLog('ERROR', e)
    return null
  }
}

export async function antiCaptchaSolve(config, proxy, emailAddress) {
  const timerStart = performance.now()
  let { proxyHost, proxyPort, proxyType, user, pass } = proxy
  if (!isIpAddress(proxyHost)) {
    try {
      proxyHost = await dns.promises.lookup(proxyHost).then(
        (res) => {
          return res.address
        },
        (err) => {
          verboseLog('ERROR', `Error resolving proxy hostname`)
          return null
        }
      )
    } catch (e) {
      verboseLog('ERROR', `Error resolving proxy hostname`)
      return null
    }
  }
  const data = {
    clientKey: config.antiCaptchaApiKey,
    task: {
      type: 'HCaptchaTask',
      websiteURL: config.websiteUrl,
      websiteKey: config.siteKey,
      proxyType: proxyType,
      proxyAddress: proxyHost,
      proxyPort: proxyPort
    }
  }
  if (user != null && pass != null) {
    data.task.proxyLogin = user
    data.task.proxyPassword = pass
  }
  const url = 'https://api.anti-captcha.com/createTask'
  let taskId = null
  let captchaResponse = null
  try {
    for (let i = 0; i < 5; i++) {
      taskId = await axios.post(url, data).then((res) => {
        return res.data.taskId
      })
      if (taskId == null) {
        verboseLog('ERROR', `${emailAddress} | Error getting taskId`)
        await sleep(1000)
        continue
      }
      verboseLog('INFO', `${emailAddress} | Got taskId ${taskId}`)
      break
    }
    if (taskId == null) {
      throw new Error('Error getting taskId')
    }
    const getResultUrl = 'https://api.anti-captcha.com/getTaskResult'
    const getResultData = {
      clientKey: config.antiCaptchaApiKey,
      taskId: taskId
    }
    while (true) {
      const getResult = await axios
        .post(getResultUrl, getResultData)
        .then((res) => {
          return res.data
        })
      if (getResult.errorId != 0) {
        verboseLog('ERROR', `${emailAddress} | Error getting captcha response`)
        verboseLog('ERROR', getResult.errorDescription)
        return null
      }
      if (getResult.errorId == 0 && getResult.status == 'processing') {
        await sleep(5000)
        continue
      }
      if (getResult.status == 'ready') {
        captchaResponse = getResult.solution.gRecaptchaResponse
        const timerEnd = performance.now()
        const totalTime = Math.floor((timerEnd - timerStart) / 1000)
        const shortResponse =
          captchaResponse.slice(0, 8) + '...' + captchaResponse.slice(-8)
        verboseLog(
          'NOTICE',
          `${emailAddress} | Got captcha response ${shortResponse} in ${totalTime} seconds`
        )
        break
      }
    }
    return captchaResponse
  } catch (e) {
    const timerEnd = performance.now()
    const totalTime = Math.floor((timerEnd - timerStart) / 1000)

    verboseLog(
      'ERROR',
      `${emailAddress} Error getting captcha Response in ${totalTime} seconds`
    )
    verboseLog('ERROR', e)
    return null
  }
}

export async function capSolverSolve(config, proxy, emailAddress) {
  const timerStart = performance.now()
  let proxyFull
  if (config.separateProxy == true) {
    proxyFull = proxy.otherProxy
  } else {
    proxyFull = proxy.proxyFull
  }
  const websiteUrl = config.websiteUrl
  const apiKey = config.capSolverApiKey
  const siteKey = config.siteKey
  const url = 'https://api.capsolver.com/createTask'
  const data = {
    clientKey: apiKey,
    task: {
      type: 'HCaptchaTask',
      websiteUrl: websiteUrl,
      websiteKey: siteKey,
      proxy: proxyFull
    }
  }
  let [taskId, captchaResponse] = [null, null]
  try {
    for (let i = 0; i < 5; i++) {
      taskId = await axios.post(url, data).then((res) => {
        return res.data.taskId
      })
      if (taskId == null) {
        verboseLog('ERROR', `${emailAddress} | Error getting taskId`)
        await sleep(5000)
        continue
      }
      verboseLog('INFO', `${emailAddress} | Got taskId ${taskId}`)
      break
    }
    if (taskId == null) {
      throw new Error('Error getting taskId')
    }
    const getResultUrl = 'https://api.capsolver.com/getTaskResult'
    const getResultData = {
      clientKey: apiKey,
      taskId: taskId
    }
    while (true) {
      const getResult = await axios
        .post(getResultUrl, getResultData)
        .then((res) => {
          return res.data
        })
      if (getResult.errorId != 0) {
        verboseLog('ERROR', `${emailAddress} | Error getting captcha response`)
        verboseLog('ERROR', getResult.errorDescription)
        return null
      }
      if (getResult.errorId == 0 && getResult.status == 'processing') {
        await sleep(5000)
        continue
      }
      if (getResult.status == 'ready') {
        captchaResponse = getResult.solution.gRecaptchaResponse
        verboseLog('INFO', `${emailAddress} | Got captcha response`)
        const timerEnd = performance.now()
        const totalTime = Math.floor((timerEnd - timerStart) / 1000)
        const shortResponse =
          captchaResponse.slice(0, 8) + '...' + captchaResponse.slice(-8)
        verboseLog(
          'NOTICE',
          `${emailAddress} | Got captcha response ${shortResponse} in ${totalTime} seconds`
        )
        break
      }
    }
    return captchaResponse
  } catch (e) {
    verboseLog('ERROR', `${emailAddress} Error getting captcha Response`)
    verboseLog('ERROR', e)
    return null
  }
}

export async function getCapSolverBalance(config) {
  const apiKey = config.capSolverApiKey
  const url = 'https://api.capsolver.com/getBalance'
  const data = {
    clientKey: apiKey
  }
  let balance
  try {
    const checkBalance = await axios.post(url, data)
    balance = checkBalance.data.balance
    if (balance <= 0.0008) {
      verboseLog('INFO', `capSolver balance: 0`)
      return null
    } else if (balance == null) {
      verboseLog('INFO', `capSolver balance not found`)
      return null
    } else if (typeof balance != 'number') {
      verboseLog('INFO', `capSolver balance not found`)
      return null
    }
  } catch (e) {
    verboseLog('ERROR', `Error getting capSolver balance`)
    return null
  }
  verboseLog('INFO', `capSolver balance: ${balance}`)
  return balance
}
export async function getAntiCaptchaBalance(config) {
  const url = 'https://api.anti-captcha.com/getBalance'
  const apiKey = config.antiCaptchaApiKey
  const header = {
    'Content-Type': 'application/json'
  }
  const data = {
    clientKey: apiKey
  }
  let balance = null
  try {
    for (let i = 0; i < 5; i++) {
      balance = await axios
        .post(url, data, {
          headers: header
        })
        .then((res) => {
          return res.data.balance
        })

      if (balance == null) {
        await sleep(1000)
        continue
      }
    }
    if (!balance) {
      verboseLog('INFO', `antiCaptcha balance: 0`)
      throw new Error('failed to get antiCaptcha balance')
    }
    if (balance <= 0.002) {
      verboseLog('INFO', `antiCaptcha balance: 0`)
      return null
    }
    verboseLog('INFO', `antiCaptcha balance: ${balance}`)
    return balance
  } catch (e) {
    verboseLog('ERROR', `Error getting antiCaptcha balance`)
    verboseLog('ERROR', `getAntiCaptchaBalance: ${e}`)
    return null
  }
}
export async function getnoCaptchaAiCredit(config) {
  const apiKey = config.noCaptchaAiApiKey
  const url = 'https://manage.nocaptchaai.com/balance'
  const headers = {
    'Content-Type': 'application/json',
    apikey: apiKey
  }
  try {
    while (true) {
      const balance = await axios
        .get(url, {
          headers: headers
        })
        .then((res) => {
          if (res.status == 502) {
            return null
          }
          return res
        })
      if (balance == null) {
        await sleep(1000)
        continue
      }
      if (balance.data.Subscription) {
        if (balance.data.Subscription.remaining == null) {
          verboseLog('INFO', `noCaptchaAi Subscription remaining not found`)
          return null
        } else if (balance.data.Subscription.remaining <= 1) {
          verboseLog('INFO', `noCaptchaAi credit: 0`)
          return 'sleep'
        } else {
          verboseLog(
            'INFO',
            `noCaptchaAi remaining: ${balance.data.Subscription.remaining}`
          )
          return balance.data.Subscription.remaining
        }
      } else {
        if (balance.data.balance == null || balance.data.balance <= 1) {
          verboseLog('INFO', `noCaptchaAi credit is low`)
          return null
        } else {
          verboseLog('INFO', `noCaptchaAi credit: ${balance.data.balance}`)
          return balance.data.balance
        }
      }
    }
  } catch (e) {
    verboseLog('ERROR', `Error getting noCaptchaAi credit`)
    verboseLog('ERROR', e)
    return null
  }
}

export async function resendCode(generatedData, mailAddress, proxy, config) {
  let proxyFull
  if (config.separateProxy == true) {
    proxyFull = proxy.otherProxy
  } else {
    proxyFull = proxy.proxyFull
  }
  const { protocol } = new URL(proxyFull)
  const userAgent = generatedData.userAgent
  let proxyAgent
  const resendUrl = `https://eu1.storj.io/api/v0/auth/resend-email/${mailAddress}`
  try {
    if (protocol == 'socks5:') {
      proxyAgent = new SocksProxyAgent(proxy.proxyFull)
    } else if (protocol == 'http:') {
      proxyAgent = new HttpProxyAgent(proxy.proxyFull)
    }
  } catch (e) {
    verboseLog('ERROR', `Error resending code for ${mailAddress}`)
    verboseLog('ERROR', e)
    return null
  }
  const headers = {
    Host: 'eu1.storj.io',
    Connection: 'keep-alive',
    'User-Agent': userAgent,
    'Content-Type': 'application/json',
    Accept: '*/*',
    Origin: 'https://eu1.storj.io',
    Referer: 'https://eu1.storj.io/signup',
    'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'en-US,en;q=0.9',
    'Sec-Fetch-Dest': 'empty',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Site': 'same-origin'
  }
  const data = mailAddress
  try {
    const resendCode = await axios.get(resendUrl, data, {
      headers: headers,
      httpAgent: proxyAgent,
      httpsAgent: proxyAgent
    })
    if (resendCode.status == 200) {
      verboseLog('INFO', resendCode.data)
      const requestId = resendCode.headers['x-request-id']
      verboseLog('INFO', `Resend code success for ${mailAddress}`)
      return requestId
    } else {
      verboseLog('ERROR', `Error resending code for ${mailAddress}`)
      return null
    }
  } catch (e) {
    verboseLog('ERROR', `Error resending code for ${mailAddress}`)
    verboseLog('ERROR', e)
    return null
  }
}

export async function signUpStorj2(
  generateData,
  config,
  mailAddress,
  proxy,
  captchaResponse
) {
  let proxyFull
  if (config.separateProxy == true) {
    proxyFull = proxy.otherProxy
  } else {
    proxyFull = proxy.proxyFull
  }
  const { protocol } = new URL(proxyFull)
  let proxyAgent
  if (protocol == 'socks5:') {
    proxyAgent = new SocksProxyAgent(proxyFull)
  } else if (protocol == 'http:') {
    proxyAgent = new HttpProxyAgent(proxyFull)
  }
  const fullName = generateData.fullName
  const password = generateData.password
  const userAgent = generateData.userAgent
  const headers = {
    Host: 'eu1.storj.io',
    Connection: 'keep-alive',
    'User-Agent': userAgent,
    'Content-Type': 'application/json',
    Accept: '*/*',
    Origin: 'https://eu1.storj.io',
    Referer: 'https://eu1.storj.io/signup',
    'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'en-US,en;q=0.9',
    'Sec-Fetch-Dest': 'empty',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Site': 'same-origin'
  }
  const data = {
    secret: '',
    password: password,
    fullName: fullName,
    shortName: '',
    email: mailAddress,
    partner: '',
    isProfessional: false,
    position: '',
    companyName: '',
    storageNeeds: 'Less than 150TB',
    employeeCount: '1-50',
    haveSalesContact: false,
    captchaResponse: captchaResponse,
    signupPromoCode: ''
  }

  const signUpUrl = 'https://eu1.storj.io/api/v0/auth/register'
  const signUp = await request.newContext({
    proxy: { server: proxyFull },
    userAgent: userAgent,
    headers: headers
  })
  try {
    const signUpResponse = await signUp.post(signUpUrl, data)

    if (signUpResponse.ok()) {
      verboseLog('INFO', `Signup success for ${mailAddress}`)
      const requestId = signUpResponse.headers()['x-request-id']
      return requestId
    } else {
      verboseLog('ERROR', `Error signing up for ${mailAddress}`)
      verboseLog('ERROR', signUpResponse.status())
      return null
    }
  } catch (e) {
    verboseLog('ERROR', `Error signing up for ${mailAddress}`)
    verboseLog('ERROR', e)
    return null
  }
}

export async function signUpStorj(
  generatedData,
  mailAddress,
  proxy,
  captchaResponse
) {
  const { protocol } = new URL(proxy.otherProxy)
  let proxyAgent
  try {
    if (protocol == 'socks5:') {
      proxyAgent = new SocksProxyAgent(proxy.otherProxy)
    } else if (protocol == 'http:') {
      proxyAgent = new HttpProxyAgent(proxy.otherProxy)
    }
    const fullName = generatedData.fullName
    const password = generatedData.password
    const userAgent = generatedData.userAgent
    const headers = {
      Host: 'eu1.storj.io',
      Connection: 'keep-alive',
      'User-Agent': userAgent,
      'Content-Type': 'application/json',
      Accept: '*/*',
      Origin: 'https://eu1.storj.io',
      Referer: 'https://eu1.storj.io/signup',
      'Accept-Encoding': 'gzip, deflate, br',
      'Accept-Language': 'en-US,en;q=0.9',
      'Sec-Fetch-Dest': 'empty',
      'Sec-Fetch-Mode': 'cors',
      'Sec-Fetch-Site': 'same-origin'
    }
    const data = {
      secret: '',
      password: password,
      fullName: fullName,
      shortName: '',
      email: mailAddress,
      partner: '',
      partnerId: '',
      isProfessional: false,
      position: '',
      companyName: '',
      employeeCount: '',
      haveSalesContact: false,
      signupPromoCode: '',
      captchaResponse: captchaResponse
    }
    while (true) {
      const url = 'https://eu1.storj.io/api/v0/auth/register'
      const signUp = await axios
        .post(url, data, {
          headers: headers,
          httpAgent: proxyAgent,
          httpsAgent: proxyAgent
        })
        .then((res) => {
          return res
        })
        .catch((err) => {
          if (err.message.includes('redirects')) {
            console.log(
              'Max redirects limit reached. Last URL:',
              err.response.request.res.responseUrl
            )
          }
          return err.response
        })
      if (signUp.status == undefined) {
        await sleep(3000)
        continue
      }
      if (signUp.status == 200) {
        const requestId = signUp.headers['x-request-id']
        verboseLog(
          'INFO',
          `Signup success for ${mailAddress} with requestId: ${requestId}`
        )
        return requestId
      } else {
        verboseLog('ERROR', `Error signing up for ${mailAddress}`)
        verboseLog('ERROR', signUp.status)
        verboseLog('ERROR', signUp.data.error)
        return null
      }
    }
  } catch (e) {
    verboseLog('ERROR', `Error signing up ${mailAddress}`)
    verboseLog('ERROR', e)
  }
}

export async function testConfig(config, proxy) {
  const baseUrl = config.baseUrl
  const chiaChunkApiKey = config.chiaChunkApiKey
  const skip = config.skip
  const useSolver = config.useSolver
  let [creditResult, chiaChunkResult, proxyResult] = [null, null, null]
  const useSolverMapping = {
    noCaptchaAiApiKey: {
      func: noCaptchaAiSolve,
      getCredit: getnoCaptchaAiCredit
    },
    capSolverApiKey: { func: capSolverSolve, getCredit: getCapSolverBalance },
    antiCaptchaApiKey: {
      func: antiCaptchaSolve,
      getCredit: getAntiCaptchaBalance
    }
  }
  verboseLog('NOTICE', `using solver ${useSolver}`)
  if (config.separateProxy == true) {
    verboseLog('NOTICE', `using separate proxy`)
  }
  while (true) {
    try {
      if (skip) {
        creditResult = await useSolverMapping[useSolver].getCredit(config)
        break
      } else {
        creditResult = await useSolverMapping[useSolver].getCredit(config)
        if (creditResult == null) {
          process.exit(1)
        } else if (creditResult == 'sleep') {
          await sleep(360000)
          continue
        } else {
          verboseLog('SUCCESS', `noCaptchaAiApiKey are valid`)
          break
        }
      }
    } catch (e) {
      verboseLog('ERROR', `Error getting credit`)
      return 1
    }
  }
  try {
    const chiaChunkUrl = new URL(`/user`, `${baseUrl}`)
    chiaChunkUrl.searchParams.append('apiKey', chiaChunkApiKey)
    chiaChunkResult = await axios.get(chiaChunkUrl.toString())
    if (chiaChunkResult.data.success == true) {
      verboseLog('SUCCESS', `chiaChunk are valid`)
    }
    proxyResult = await changeIp(proxy)
    if (proxyResult == 0) {
      verboseLog('SUCCESS', `proxy are valid`)
    } else {
      verboseLog('ERROR', `proxy are invalid`)
      return 1
    }
    verboseLog('SUCCESS', `All Config are valid`)
    return 0
  } catch (e) {
    verboseLog('ERROR', `Error testing config`)
    verboseLog('ERROR', e)
    return 1
  }
}

export async function loginGen(data, proxy, cookie, email) {
  const { protocol } = new URL(proxy.proxyFull)
  let proxyAgent, proxyPw
  if (protocol == 'socks5:') {
    proxyAgent = new SocksProxyAgent(proxy.proxyFull)
    proxyPw = {
      server: proxy.proxyFull
    }
  } else if (protocol == 'http:') {
    proxyAgent = new HttpProxyAgent(proxy.proxyFull)
    proxyPw = {
      server: proxy.proxyFull,
      username: proxy.user,
      password: proxy.pass
    }
  }
  verboseLog('INFO', `Starting login for ${email}`)
  try {
    const browser = await chromium.launch({
      proxy: proxyPw,
      headless: false,
      userAgent: data.userAgent
    })
    const context = await browser.newContext()
    const projectName = data.projectName
    const accessName = data.accessName
    const password = data.password
    const passPhrase = data.password
    const fullName = data.fullName
    const page = await context.newPage()
    try {
      while (true) {
        try {
          await page.goto('https://eu1.storj.io/login')
          await page.waitForLoadState('networkidle')
          break
        } catch (e) {}
      }
      await page.waitForTimeout(1000)
      try {
        await page.evaluate((cookie) => {
          document.cookie = `_tokenKey=${cookie}; path=/; domain=eu1.storj.io;`
        }, cookie)
      } catch (e) {
        console.log(e)
      }
      await page.goto('https://eu1.storj.io/all-projects')
      await sleep(randTimeout(1000, 5000))
      try {
        await page.waitForSelector('text=My Projects')
      } catch (e) {
        console.log(`Error login satu ${email}`)
        await browser.close()
        console.log(e)
        return null
      }
      cookie = await page.context().cookies()
      cookie = cookie.filter((item) => item.name == '_tokenKey')
      const headers = {
        'User-Agent': data.userAgent,
        cookie: `_tokenKey=${cookie[0].value}`,
        Origin: 'https://eu1.storj.io',
        Referer: 'https://eu1.storj.io/all-projects',
        'Content-Type': 'application/json',
        Accept: '*/*',
        'Accept-Encoding': 'gzip, deflate, br',
        'Accept-Language': 'en-US,en;q=0.9',
        'Sec-Fetch-Dest': 'empty',
        'Sec-Fetch-Mode': 'cors',
        'Sec-Fetch-Site': 'same-origin'
      }
      //inject cookie to headers
      await page.evaluate((cookie) => {
        document.cookie = `_tokenKey=${cookie[0].value}; path=/; domain=eu1.storj.io;`
      }, cookie)
      const openProject = (await page.$('text=Open Project')) ? true : false
      if (openProject) {
        await page.locator('text=Open Project').first().click()
      } else {
        await page.getByText('Create a Project').nth(1).click()
        await page.getByPlaceholder('Enter Project Name').click()
        await sleep(randTimeout(500, 1000))
        await page.getByPlaceholder('Enter Project Name').fill(projectName)
        const createProject = (await page.$('text=Create Project -->'))
          ? true
          : false
        if (!createProject) {
          await sleep(randTimeout(500, 1000))
          //press tab 3 times and press enter
          await page.keyboard.press('Tab')
          await sleep(randTimeout(500, 1000))
          await page.keyboard.press('Tab')
          await sleep(randTimeout(500, 1000))
          await page.keyboard.press('Tab')
          await sleep(randTimeout(500, 1000))
          await page.keyboard.press('Enter')
          await sleep(randTimeout(500, 1000))
        } else {
          try {
            await sleep(randTimeout(500, 1000))
            await page.getByText('Create Project -->').click()
          } catch (e) {
            await page.getByPlaceholder('Enter Project Name').click()
            await sleep(randTimeout(500, 1000))
            await page.getByPlaceholder('Enter Project Name').fill(projectName)
            await sleep(randTimeout(500, 1000))
            await page.getByText('Create Project -->').click()
          }
        }
      }
      let phasePraseDialogpage
      await page.waitForTimeout(1000)
      sleep(randTimeout(500, 1000))
      phasePraseDialogpage = (await page.$('text=Start with web browser'))
        ? true
        : false
      if (phasePraseDialogpage) {
        await page.click('text=Start with web browser')
      }
      const skipDialog = (await page.$(
        'text=Skip and go directly to dashboard'
      ))
        ? true
        : false

      if (skipDialog) {
        await page.getByText('Skip and go directly to dashboard').click()
      }
      await page.waitForTimeout(500)
      const phasePraseDialog = (await page.$('text=Encryption Passphrase'))
        ? true
        : false
      if (phasePraseDialog) {
        await page.locator('.mask__wrapper__container__close').click()
      }
      await sleep(randTimeout(500, 1000))
      await page.goto('https://eu1.storj.io/all-projects')
      await page.waitForTimeout(500)
      await page.locator('text=Open Project').first().click()
      await sleep(randTimeout(500, 1000))
      const skipButton = page.getByText('Skip') ? true : false
      if (skipButton) {
        try {
          await page.locator('.mask__wrapper__container__close').click()
        } catch (e) {}
      }
      phasePraseDialogpage = (await page.$('text=Start with web browser'))
        ? true
        : false
      if (phasePraseDialogpage) {
        await page.goto('https://eu1.storj.io/all-projects')
        await page.waitForTimeout(500)
        await page.locator('text=Open Project').first().click()
      }
      await sleep(randTimeout(500, 1000))
      const accessButton = page.getByText('Access') ? true : false
      if (accessButton) {
        try {
          await page.locator('text=Access').first().click()
        } catch (e) {
          await page.goto('https://eu1.storj.io/access-grants')
          await page.waitForTimeout(500)
        }
      }
      await sleep(1000)
      await page.reload()
      await page.waitForTimeout(500)
      await page.getByText('Create S3 Credentials').click()
      await page.getByPlaceholder('Input Access Name').click()
      await page.getByPlaceholder('Input Access Name').fill(accessName)
      await page
        .locator('div')
        .filter({ hasText: /^Access GrantS3 CredentialsCLI Access$/ })
        .locator('span')
        .first()
        .click()
      await page.getByText('Continue ->').click()
      await sleep(randTimeout(500, 1000))
      await page
        .locator('div')
        .filter({ hasText: /^I understand*/ })
        .locator('span')
        .click()
      await page.getByText('Continue ->').click()
      await sleep(1000)
      await page.getByText('Continue ->').click()
      await sleep(1000)
      await page.getByText('Create Access ->').click()
      await page.getByPlaceholder('Enter Encryption Passphrase').click()
      await page.getByPlaceholder('Enter Encryption Passphrase').fill(password)
      await page.getByText('Create Access ->').click()
      await sleep(1000)
      await page.getByText('Confirm').nth(1).click()
      await sleep(randTimeout(1000, 2000))
      //await page.getByText('Show Access Key').click()
      //await page.getByText('Show Secret Key').click()
      //await page.getByText('Show Endpoint').click()
      //locate p tag with class blured-container__wrap__text shown
      //wait until page.locator('.blured-container__wrap__text') appear
      await page.waitForSelector('.blured-container__wrap__text')
      const credentialLocation = page.locator('.blured-container__wrap__text')
      const accessGrant = await credentialLocation.first().textContent()
      await sleep(randTimeout(500, 1000))
      await page.getByText('Next', { exact: true }).click()
      const accessKey = await credentialLocation.nth(0).textContent()
      const secretKey = await credentialLocation.nth(1).textContent()
      const endpoint = await credentialLocation.nth(2).textContent()
      await page.close()
      await browser.close()

      const projectId = await axios
        .get('https://eu1.storj.io/api/v0/projects', {
          headers: headers,
          httpAgent: proxyAgent,
          httpsAgent: proxyAgent
        })
        .then((response) => {
          if (response.status == 200) {
            return response.data[0].id
          } else {
            console.log('Get project id failed')
          }
        })
      const setSessionTimeout = await axios
        .patch(
          'https://eu1.storj.io/api/v0/auth/account/settings',
          {
            sessionDuration: 2592000000000000
          },
          {
            headers: headers,
            httpAgent: proxyAgent,
            httpsAgent: proxyAgent
          }
        )
        .then((response) => {
          if (response.status == 200) {
            return response.data.sessionDuration
          } else {
            console.log('Set session timeout failed')
          }
        })
        .catch((error) => {
          console.log(error)
        })
      const accountCreatedAt = await axios
        .get(`https://eu1.storj.io/api/v0/auth/account`, {
          headers: headers,
          httpAgent: proxyAgent,
          httpsAgent: proxyAgent
        })
        .then((response) => {
          if (response.status == 200) {
            return response.data.createdAt
          } else {
            throw new Error('Get account created date failed')
          }
        })
      cookie = cookie[0].value
      let saveData = `${email}|${password}|${accessKey}|${secretKey}|${endpoint}|${accessGrant}|${projectId}|${cookie}|${accountCreatedAt}|${setSessionTimeout}`
      //save saveData to file data.txt
      fs.appendFile('fulldata.txt', `${saveData}\n`, (err) => {
        if (err) {
          console.log(err)
        }
      })

      verboseLog('SUCCESS', `${email}`)
      await browser.close()
      return {
        email: email,
        password: password,
        passPhrase: passPhrase,
        accessKey: accessKey,
        secretKey: secretKey,
        endpoint: endpoint,
        accessGrant: accessGrant,
        projectId: projectId,
        cookie: cookie,
        accountCreatedAt: accountCreatedAt,
        setSessionTimeout: setSessionTimeout
      }
    } catch (e) {
      await sleep(30000)
      await page.close()
      await browser.close()
      verboseLog('ERROR', `Error login dua ${email}`)
      console.log(e)
    }
  } catch (e) {
    verboseLog('ERROR', `Error login tiga ${email}`)
    await page.close()
    await browser.close()
    console.log(e)
  }
}

export async function getConfirmCode(emailAddress, proxy) {
  const user = emailAddress.split('@')[0]
  const domain = emailAddress.split('@')[1]
  const { protocol } = new URL(proxy.proxyFull)
  let proxyAgent = null
  if (protocol === 'socks5:') {
    proxyAgent = new SocksProxyAgent(proxy.proxyFull)
  } else if (protocol === 'http:') {
    proxyAgent = new HttpProxyAgent(proxy.proxyFull)
  }
  const mainCookie =
    '_ga=GA1.2.747718287.1611551159; _gid=GA1.2.786119622.1615220663; ' +
    'embx=%5B%22dogeanjay00%40gxmer.com%22%2C%22ayamanjay%40bedul.net' +
    '%22%2C%22ngawurnajayy%40plitur.com%22%2C%222ionel.radu.9826%40coronagg.com' +
    '%22%2C%221ahmad.pop%40hustletussle.com%22%2C%22hmohame%40acmta.com' +
    '%22%2C%22qsmar%40ucombinator.com%22%2C%22zlimon.shuvo29%40furnitt.com' +
    '%22%2C%22odmsal1%40wikuiz.com%22%5D; _gat=1; ' +
    `surl=${domain}%2F${user}`
  const mainUrl = 'https://generator.email/inbox5/'
  const mainHeaders = {
    Cookie: mainCookie
  }
  try {
    const inbox = await axios.get(mainUrl, {
      headers: mainHeaders,
      httpAgent: proxyAgent,
      httpsAgent: proxyAgent
    })
    const inboxData = cheerio.load(inbox.data)
    const emailTable = inboxData('#email-table')
    function getCode(data) {
      try {
        const code = data
          .find(
            'h1[style="font-family: Helvetica, sans-serif; font-weight: 500; line-height: 1.2; mso-line-height-alt: 14px; margin: 20px 0"]'
          )
          .text()
          .trim()
        return code
      } catch (err) {
        verboseLog('ERROR', `Error getting confirm code: ${err}`)
      }
    }
    let code
    if (emailTable.length == 0) {
      verboseLog('ERROR', `${emailAddress} inbox not found`)
      return null
    } else {
      let inboxUrl = emailTable.find('a').attr('href')
      if (!inboxUrl.includes(user)) {
        code = getCode(emailTable)
      } else {
        const inboxPath = inboxUrl.split('/').pop()
        const inboxCookie = `embx=%5B%22${user}%40${domain}%22%5D; surl=${domain}%2F${user}%2F${inboxPath}`
        const inboxHeaders = {
          Cookie: inboxCookie
        }
        inboxUrl = `https://generator.email/inbox2/`
        const inboxData2 = await axios.get(inboxUrl, {
          headers: inboxHeaders,
          httpAgent: proxyAgent,
          httpsAgent: proxyAgent
        })
        const inboxData2Data = cheerio.load(inboxData2.data)
        const inboxEmailTable = inboxData2Data('#email-table')
        code = getCode(inboxEmailTable)
      }
      return code
    }
  } catch (err) {
    verboseLog('ERROR', `Error getting confirm code: ${err}`)
  }
}

export async function completeSignup(
  generatedData,
  mailAddress,
  code,
  requestId,
  proxy
) {
  const { protocol } = new URL(proxy.proxyFull)
  const userAgent = generatedData.userAgent
  let proxyAgent
  const activationUrl = `https://eu1.storj.io/api/v0/auth/code-activation`
  const data = {
    email: mailAddress,
    code: code,
    signupId: requestId
  }
  let signUp
  try {
    if (protocol == 'socks5:') {
      proxyAgent = new SocksProxyAgent(proxy.proxyFull)
    } else if (protocol == 'http:') {
      proxyAgent = new HttpProxyAgent(proxy.proxyFull)
    }

    const headers = {
      Host: 'eu1.storj.io',
      Connection: 'keep-alive',
      'User-Agent': userAgent,
      'Content-Type': 'application/json',
      Accept: '*/*',
      Origin: 'https://eu1.storj.io',
      Referer: 'https://eu1.storj.io/signup',
      'Accept-Encoding': 'gzip, deflate, br',
      'Accept-Language': 'en-US,en;q=0.9',
      'Sec-Fetch-Dest': 'empty',
      'Sec-Fetch-Mode': 'cors',
      'Sec-Fetch-Site': 'same-origin'
    }
    try {
      signUp = await axios.patch(activationUrl, data, {
        headers: headers,
        httpAgent: proxyAgent,
        httpsAgent: proxyAgent
      })
      if (signUp.status == 200) {
        verboseLog('INFO', `Activation up success for ${mailAddress}`)
        let cookie = signUp.headers['set-cookie'].split(';')[0]
        //remove __tokenKey from cookie
        cookie = cookie.replace('__tokenKey=', '')
        return cookie
        
      }
    } catch (e) {
      if (e.response && e.response.data) {
        throw new Error(e.response.data.error)
      }
    }
  } catch (e) {
    verboseLog('ERROR', `Error resending code for ${mailAddress}`)
    verboseLog('ERROR', e)
    return null
  }
}
