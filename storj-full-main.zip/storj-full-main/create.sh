#!/usr/local/env bash

#processPids=()
#changeIp=true
#actionNum=0#

#while true; do
#  if [[ $changeIp == true ]]; then
#    node index.js --test true
#    if [[ $? == 0 ]]; then
#      changeIp=false
#      actionNum=0
#    else
#      echo "change ip failed"
#      exit 1
#    fi
#  fi
#  if [[ $actionNum -eq 5 ]]; then
#    for pid in ${processPids[@]}; do
#      wait $pid
#    done
#    processPids=()
#    changeIp=true
#    actionNum=0
#    continue
#  fi
#  node index.js &
#  processPids+=($!)
#  actionNum=$((actionNum + 1))
#  sleep 3
#done

seq inf | parallel -j 30 'node solveCaptcha.js {}'
