import { SocksProxyAgent } from 'socks-proxy-agent'
import { default as ConfigParser } from 'configparser'
import axios from 'axios'
import path from 'path'
import { HttpsProxyAgent as HttpProxyAgent } from 'https-proxy-agent'
const __dirname = path.dirname(new URL(import.meta.url).pathname)

function generateRandomString(length) {
  let result = ''
  const characters = 'abcdefghijklmnopqrstuvwxyz'
  const charactersLength = characters.length
  for (let i = 0; i < length; i++) {
    result += characters.charAt(Math.floor(Math.random() * charactersLength))
  }
  return result
}

export async function parseConfig() {
  const config = new ConfigParser()
  config.read(path.join(__dirname, 'config.conf'))
  const main = {
    baseUrl: config.get('main', 'baseUrl'),
    chiaChunkApiKey: config.get('main', 'chiaChunkApiKey'),
    siteKey: config.get('main', 'siteKey'),
    websiteUrl: config.get('main', 'websiteUrl'),
    useSolver: config.get('main', 'useSolver'),
    skip: config.get('main', 'skip') === 'true' ? true : false,
    useDataImpulse: config.get('main', 'useDataImpulse')
  }
  const proxy = config._sections.proxy
  const captchaApiKey = config._sections.captchaApiKey
  const dataImpulse = config._sections.dataImpulse
  dataImpulse.useSticky = dataImpulse.useSticky === 'true' ? true : false
  proxy.proxyUser = proxy.proxyUser === '' ? null : proxy.proxyUser
  proxy.proxyPass = proxy.proxyPass === '' ? null : proxy.proxyPass
  if (!proxy.proxyFull) {
    if (proxy.proxyUser && proxy.proxyPass) {
      proxy.proxyFull = `${proxy.proxyType}://${proxy.proxyUser}:${proxy.proxyPass}@${proxy.proxyHost}:${proxy.proxyPort}`
    } else {
      proxy.proxyFull = `${proxy.proxyType}://}${proxy.proxyHost}:${proxy.proxyPort}`
    }
  }

  dataImpulse.countrySet =
    dataImpulse.countrySet === '' ? null : dataImpulse.countrySet
  const result = {
    main,
    captchaApiKey,
    proxy,
    dataImpulse
  }
  return result
}

export async function genDataImpulse(data) {
  const config = data.config
  const dIConfig = config.dataImpulse
  let result,
    proxyPort,
    proxyFull = null
  let proxyUser = dIConfig.proxyUser
  if (dIConfig.countrySet !== null) {
    proxyUser += '__cr.' + dIConfig.countrySet
  }
  if (dIConfig.countrySet !== null && dIConfig.useSticky) {
    proxyUser += ';'
  }
  if (dIConfig.useSticky) {
    const randString = generateRandomString(6)
    proxyUser += '__sessid.' + randString
    proxyPort = 10000 + Math.floor(Math.random() * 20)
  } else {
    if (dIConfig.proxyType === 'socks5') {
      proxyPort = 824
    } else if (dIConfig.proxyType === 'http') {
      proxyPort = 823
    }
  }
  if (dIConfig.proxyUser && dIConfig.proxyPass) {
    proxyFull = `${dIConfig.proxyType}://${proxyUser}:${dIConfig.proxyPass}@${dIConfig.proxyHost}:${proxyPort}`
  }
  let proxyAgent
  if (dIConfig.proxyType === 'socks5') {
    proxyAgent = new SocksProxyAgent(proxyFull)
  } else if (dIConfig.proxyType === 'http') {
    proxyAgent = new HttpProxyAgent(proxyFull)
  }
  let ipDetail = null
  if (dIConfig.useSticky) {
    ipDetail = await axios
      .get('https://ipinfo.io', {
        httpsAgent: proxyAgent
      })
      .then((res) => res.data)
      .catch((err) => {
        return null
      })
  }
  result = {
    dataImpulse: dIConfig,
    proxy: {
      proxyUser: proxyUser,
      proxyPass: dIConfig.proxyPass,
      proxyHost: dIConfig.proxyHost,
      proxyPort: Number(proxyPort),
      proxyType: dIConfig.proxyType,
      proxyFull
    },
    ipDetail
  }
  return result
}
