import { chromium, request } from 'playwright-extra'
import StealthPlugin from 'puppeteer-extra-plugin-stealth'
import {
  randTimeout,
  changeIp,
  parseConfig,
  parseProxy,
  completeSignup,
  getConfirmCode,
  generateData,
  sleep,
  getMailAddress,
  getConfirmUrl2,
  noCaptchaAiSolve,
  getnoCaptchaAiCredit,
  capSolverSolve,
  getCapSolverBalance,
  antiCaptchaSolve,
  getAntiCaptchaBalance,
  twoCaptchaSolve,
  getTwoCaptchaCredit,
  signUpStorj,
  loginGen,
  submitStorj,
  testConfig,
  verboseLog
} from './function.js'
const hcaptchaCookie =
  'ZNd/9+NFqfw9+45SZM+L1dYR+0wDcVjiE50SHZ5wjeGwN3QLWPr0P9HmamS65CjKbkC/6/LaX5eM5udcPX5viJdFRHh/Ui+sbukzX88ckqHnIm1sS2EFdBjLE5BJtKgZeIIYZzwcF1F4o1R59Dt0415gn+C0/2Z2CQwz7vDz1Y6RnXvFG4DvbwrfcxOTHAkLtmibC7udzCwb5wDvQnyWUfnhUFjt0IjW5dAOWfoYmgDg5APBfbvJGkYkwdjlBSa7vid2nETQXp3we+KluVx3FFmjF3WPNf7NBMBpniJX+bNeN7Mb0xH6UsGkqGzjbDkyOolKfcRh/nBLBcvmGGlCc7GOA4DHRxG80hJy/eodEp+DX1yCeG7V6txyWyE9V75cRb+dNZdPCKv1F2Ex/NIu67kndWyoOY5AW52NwGkW9ZW3tJqHrB7QEQQjl0oe5HQd9mVrFF30ewbIYz/rtwPo+uIGYk7EBq46fZSOzsutXtJwVMZEs3O5U51yD1/fHvAYCsBrdRNOZgUnfBSt1dVOeaXDQyEXwYm7Nvc2/5yerUtOnSFNaB6bLrxAC4Qmfdz4MR/E1353uJYa4X1e5+6tV5Js938uh8oh/AzFNVEwb0zXkhweZCQdz4Kt+ncK7cOZ7f9V3PlB9Z8OYIz7KJnFrm7xmjjyEOmYbwk+VINsnOxVh4QHcjsW/RGyxV0wHm1Y+nhyf7ar89736ljHcqZ2UlPU6iiXJXYrW2PrpTd9EMtjgcfDrzdkN8dV89YZjP45uQ6aUhQpGTtcHR4nYfbAB4SB0MjZUzj8/u3iizJt/KqEfVTFXAq4eYMIz7dRjDZlbTpocGEQpX8ZPcHU3FG3n1NoVdHewOmw4BtxAtULVKGRIXzEiIFRKk+fEwLAtkNlN5/KI5qsbskPncqUIW79Jcpdxv2bUzDPRAcanFMeKj0++eWefeyup60RpzkyW/vjArayT/5PKZEAGdF6U1YDi/nSoVxusac6IIocIBUSR6CJJi1ka4h2Sre1LII66hpPhp+iT7dYN0/1DDTruF17rPWdCyfF3Bo/7hG0KAdzhlpp3QrcngTzp87XJ5qRcX+90wtVCQ==Xh4vfVumilR5+8wV'

;(async () => {
  const proxy = await parseProxy()
  const randString8 = Math.random().toString(36).substring(2, 10)
  const dir = `./${randString8}`
  chromium.use(StealthPlugin())
  const browser = await chromium.launchPersistentContext(dir, {
    headless: false,

    proxy: {
      server: proxy.proxyType + '://' + proxy.proxyHost + ':' + proxy.proxyPort,
      username: `${proxy.user};__sessid.${randString8}`,
      password: proxy.pass
    }
  })

  await browser.route('**/*', (route) => route.continue())

  // Pause the page, and start recording manually.
  const page = await browser.newPage()
  await page.goto('https://google.com')
  await page.pause()
})()
