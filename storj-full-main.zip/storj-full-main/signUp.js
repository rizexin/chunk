import { chromium, request } from 'playwright'
import net from 'net'
import { SocksProxyAgent } from 'socks-proxy-agent'
import pojectnamegenerator from 'project-name-generator'
import { parseConfig, genDataImpulse } from './parseConfig.js'
import { verboseLog } from './function.js'
import { default as ConfigParser } from 'configparser'
import { faker, tr } from '@faker-js/faker'
import axios from 'axios'
import path from 'path'
import fs from 'fs'
import * as cheerio from 'cheerio'
import { Performance } from 'perf_hooks'
import { HttpsProxyAgent as HttpProxyAgent } from 'https-proxy-agent'
const __dirname = path.dirname(new URL(import.meta.url).pathname)
export function isIpAddress(value) {
  return net.isIP(value) !== 0
}
export function randTimeout(min, max) {
  return Math.floor(Math.random() * (max - min + 1) + min)
}

export async function generateData() {
  try {
    const { generate } = pojectnamegenerator
    const projectName = generate({ number: true }).dashed
    const password = faker.internet.password({ length: 12 })
    const userAgent = faker.internet.userAgent()
    const accessName = generate({
      words: 2,
      alliterative: true,
      number: true
    }).spaced
    const fullName = faker.person.fullName()
    return { projectName, accessName, fullName, password, userAgent }
  } catch (e) {
    verboseLog('ERROR', `Error generating data`)
  }
}

export async function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms))
}

export async function getMailAddress(data) {
  let { proxy, config } = data
  if (
    config.main.useDataImpulse === 'captcha' ||
    config.main.useDataImpulse === 'all'
  ) {
    const dataImpulseDetail = await genDataImpulse(data)
    proxy = dataImpulseDetail.proxy
  } else {
    proxy = config.proxy
  }

  const proxyFull = proxy.proxyFull
  let proxyAgent
  try {
    const { protocol } = new URL(proxyFull)
    if (protocol == 'socks5:') {
      proxyAgent = new SocksProxyAgent(proxyFull)
    } else if (protocol == 'http:') {
      proxyAgent = new HttpProxyAgent(proxyFull)
    }
    const mailUrl = 'https://generator.email/'

    const getMail = await axios.get(mailUrl, {
      httpAgent: proxyAgent,
      httpsAgent: proxyAgent
    })
    const mailAddress = getMail.data.match(
      /<b><span id="email_ch_text">([^<]+)<\/span><\/b>/
    )[1]
    const user = mailAddress.split('@')[0]
    const domain = mailAddress.split('@')[1]
    const domainExt = domain.split('.')[1]
    return mailAddress
  } catch (e) {
    verboseLog('ERROR', `Error getting mail address`)
    verboseLog('ERROR', e)
    return null
  }
}

export async function signUpStorj(data) {
  let { config, proxy, dataImpulse, emailAddress, captchaResponse } = data
  if (
    config.main.useDataImpulse === 'signup' ||
    config.main.useDataImpulse === 'all'
  ) {
    const dataImpulseDetail = await genDataImpulse(data)
    proxy = dataImpulseDetail.proxy
  } else {
    proxy = config.proxy
  }

  const dataSignUp = await generateData()
  const { projectName, accessName, fullName, password, userAgent } = dataSignUp
  const headers = {
    Host: 'eu1.storj.io',
    Connection: 'keep-alive',
    'User-Agent': userAgent,
    'Content-Type': 'application/json',
    Accept: '*/*',
    Origin: 'https://eu1.storj.io',
    Referer: 'https://eu1.storj.io/signup',
    'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'en-US,en;q=0.9',
    'Sec-Fetch-Dest': 'empty',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Site': 'same-origin'
  }
  const body = {
    secret: '',
    password: password,
    fullName: fullName,
    shortName: '',
    email: emailAddress,
    partner: '',
    partnerId: '',
    isProfessional: false,
    position: '',
    companyName: '',
    employeeCount: '',
    haveSalesContact: false,
    signupPromoCode: '',
    captchaResponse: captchaResponse
  }
  const { protocol } = new URL(proxy.proxyFull)
  let proxyAgent
  if (protocol == 'socks5:') {
    proxyAgent = new SocksProxyAgent(proxy.proxyFull)
  } else if (protocol == 'http:') {
    proxyAgent = new HttpProxyAgent(proxy.proxyFull)
  }
  try {
    while (true) {
      const url = 'https://eu1.storj.io/api/v0/auth/register'
      const signUp = await axios
        .post(url, body, {
          headers: headers,
          httpAgent: proxyAgent,
          httpsAgent: proxyAgent
        })
        .then((res) => {
          return res
        })
        .catch((err) => {
          if (err.message.includes('redirects')) {
            console.log(
              'Max redirects limit reached. Last URL:',
              err.response.request.res.responseUrl
            )
          }
          return err.response
        })
      if (signUp.status == undefined) {
        await sleep(3000)
        continue
      }
      if (signUp.status == 200) {
        const requestId = signUp.headers['x-request-id']
        verboseLog(
          'INFO',
          `Signup success for ${emailAddress} with requestId: ${requestId}`
        )
        return { requestId, dataSignUp }
      } else {
        verboseLog('ERROR', `Error signing up for ${emailAddress}`)
        verboseLog('ERROR', signUp.status)
        verboseLog('ERROR', signUp.data.error)
        return null
      }
    }
  } catch (e) {
    verboseLog('ERROR', `Error signing up`)
    verboseLog('ERROR', e)
    return null
  }
}

export async function getConfirmCode(data) {
  let { config, dataSignUp, proxy } = data
  const emailAddress = data.emailAddress
  const user = emailAddress.split('@')[0]
  const domain = emailAddress.split('@')[1]
  if (
    config.main.useDataImpulse === 'signup' ||
    config.main.useDataImpulse === 'all'
  ) {
    const dataImpulseDetail = await genDataImpulse(data)
    proxy = dataImpulseDetail.proxy
  } else {
    proxy = config.proxy
  }
  const { protocol } = new URL(proxy.proxyFull)
  let proxyAgent = null
  if (protocol === 'socks5:') {
    proxyAgent = new SocksProxyAgent(proxy.proxyFull)
  } else if (protocol === 'http:') {
    proxyAgent = new HttpProxyAgent(proxy.proxyFull)
  }
  const mainCookie =
    '_ga=GA1.2.747718287.1611551159; _gid=GA1.2.786119622.1615220663; ' +
    'embx=%5B%22dogeanjay00%40gxmer.com%22%2C%22ayamanjay%40bedul.net' +
    '%22%2C%22ngawurnajayy%40plitur.com%22%2C%222ionel.radu.9826%40coronagg.com' +
    '%22%2C%221ahmad.pop%40hustletussle.com%22%2C%22hmohame%40acmta.com' +
    '%22%2C%22qsmar%40ucombinator.com%22%2C%22zlimon.shuvo29%40furnitt.com' +
    '%22%2C%22odmsal1%40wikuiz.com%22%5D; _gat=1; ' +
    `surl=${domain}%2F${user}`
  const mainUrl = 'https://generator.email/inbox5/'
  const mainHeaders = {
    Cookie: mainCookie
  }
  try {
    const inbox = await axios.get(mainUrl, {
      headers: mainHeaders,
      httpAgent: proxyAgent,
      httpsAgent: proxyAgent
    })
    const inboxData = cheerio.load(inbox.data)
    const emailTable = inboxData('#email-table')
    function getCode(data) {
      try {
        const code = data
          .find(
            'h1[style="font-family: Helvetica, sans-serif; font-weight: 500; line-height: 1.2; mso-line-height-alt: 14px; margin: 20px 0"]'
          )
          .text()
          .trim()
        return code
      } catch (err) {
        verboseLog('ERROR', `Error getting confirm code: ${err}`)
      }
    }
    let code
    if (emailTable.length == 0) {
      verboseLog('ERROR', `${emailAddress} inbox not found`)
      return null
    } else {
      let inboxUrl = emailTable.find('a').attr('href')
      if (!inboxUrl.includes(user)) {
        code = getCode(emailTable)
      } else {
        const inboxPath = inboxUrl.split('/').pop()
        const inboxCookie = `embx=%5B%22${user}%40${domain}%22%5D; surl=${domain}%2F${user}%2F${inboxPath}`
        const inboxHeaders = {
          Cookie: inboxCookie
        }
        inboxUrl = `https://generator.email/inbox2/`
        const inboxData2 = await axios.get(inboxUrl, {
          headers: inboxHeaders,
          httpAgent: proxyAgent,
          httpsAgent: proxyAgent
        })
        const inboxData2Data = cheerio.load(inboxData2.data)
        const inboxEmailTable = inboxData2Data('#email-table')
        code = getCode(inboxEmailTable)
      }
      return code
    }
  } catch (err) {
    verboseLog('ERROR', `Error getting confirm code: ${err}`)
    return null
  }
}

export async function completeSignup(data) {
  let { emailAddress, requestId, dataSignUp, proxy, config, code } = data
  if (
    config.main.useDataImpulse === 'signup' ||
    config.main.useDataImpulse === 'all'
  ) {
    const dataImpulseDetail = await genDataImpulse(data)
    proxy = dataImpulseDetail.proxy
  } else {
    proxy = config.proxy
  }
  const { protocol } = new URL(proxy.proxyFull)
  const userAgent = dataSignUp.userAgent
  let proxyAgent
  const activationUrl = `https://eu1.storj.io/api/v0/auth/code-activation`
  const body = {
    email: emailAddress,
    code: code,
    signupId: requestId
  }
  let signUp
  try {
    if (protocol == 'socks5:') {
      proxyAgent = new SocksProxyAgent(proxy.proxyFull)
    } else if (protocol == 'http:') {
      proxyAgent = new HttpProxyAgent(proxy.proxyFull)
    }

    const headers = {
      Host: 'eu1.storj.io',
      Connection: 'keep-alive',
      'User-Agent': userAgent,
      'Content-Type': 'application/json',
      Accept: '*/*',
      Origin: 'https://eu1.storj.io',
      Referer: 'https://eu1.storj.io/signup',
      'Accept-Encoding': 'gzip, deflate, br',
      'Accept-Language': 'en-US,en;q=0.9',
      'Sec-Fetch-Dest': 'empty',
      'Sec-Fetch-Mode': 'cors',
      'Sec-Fetch-Site': 'same-origin'
    }
    try {
      signUp = await axios.patch(activationUrl, body, {
        headers: headers,
        httpAgent: proxyAgent,
        httpsAgent: proxyAgent
      })
      if (signUp.status == 200) {
        verboseLog('INFO', `Activation success for ${emailAddress}`)
        let cookie = signUp.headers['set-cookie'][0]
        cookie = cookie.split(';')[0]
        //remove __tokenKey from cookie
        cookie = cookie.replace('_tokenKey=', '')
        return cookie
      }
    } catch (e) {
      if (e.response && e.response.data) {
        throw new Error(e.response.data.error)
      }
    }
  } catch (e) {
    verboseLog('ERROR', `Error activating for ${emailAddress}`)
    verboseLog('ERROR', e)
    return null
  }
}

export async function loginGen(data) {
  let { config, proxy, dataImpulse, dataSignUp, cookie, emailAddress } = data
  if (
    config.main.useDataImpulse === 'signup' ||
    config.main.useDataImpulse === 'all'
  ) {
    const dataImpulseDetail = await genDataImpulse(data)
    proxy = dataImpulseDetail.proxy
  } else {
    proxy = config.proxy
  }
  const projectName = await generateData().then((data) => {
    return data.projectName
  })
  const email = emailAddress
  const { protocol } = new URL(proxy.proxyFull)
  let proxyAgent, proxyPw
  if (protocol == 'socks5:') {
    proxyAgent = new SocksProxyAgent(proxy.proxyFull)
    proxyPw = {
      server: proxy.proxyFull
    }
  } else if (protocol == 'http:') {
    proxyAgent = new HttpProxyAgent(proxy.proxyFull)
    proxyPw = {
      server: proxy.proxyFull,
      username: proxy.proxyUser,
      password: proxy.proxyPass
    }
  }
  verboseLog('INFO', `Starting login for ${email}`)
  try {
    const browser = await chromium.launch({
      proxy: proxyPw,
      headless: true,
      userAgent: dataSignUp.userAgent
    })
    const context = await browser.newContext()
    const accessName = dataSignUp.accessName
    const password = dataSignUp.password
    const passPhrase = dataSignUp.password
    const fullName = dataSignUp.fullName
    const page = await context.newPage()
    try {
      while (true) {
        try {
          await page.goto('https://eu1.storj.io/login')
          await page.waitForLoadState('domcontentloaded')
          break
        } catch (e) {}
      }
      await page.waitForTimeout(1000)
      try {
        await page.evaluate((cookie) => {
          document.cookie = `_tokenKey=${cookie}; path=/; domain=eu1.storj.io;`
        }, cookie)
      } catch (e) {
        console.log(e)
      }
      await page.waitForTimeout(1000)
      await page.goto('https://eu1.storj.io/all-projects')
      await sleep(randTimeout(1000, 5000))
      for (let i = 0; i < 5; i++) {
        try {
          await page.waitForSelector('text=My Projects', {
            timeout: 30000
          })
          break
        } catch (e) {
          if (i == 4) {
            console.log(`Error login satu ${email}`)
            await browser.close()
            console.log(e)
            return null
          }
          continue
        }
      }
      cookie = await page.context().cookies()
      cookie = cookie.filter((item) => item.name == '_tokenKey')
      const headers = {
        'User-Agent': dataSignUp.userAgent,
        cookie: `_tokenKey=${cookie[0].value}`,
        Origin: 'https://eu1.storj.io',
        Referer: 'https://eu1.storj.io/all-projects',
        'Content-Type': 'application/json',
        Accept: '*/*',
        'Accept-Encoding': 'gzip, deflate, br',
        'Accept-Language': 'en-US,en;q=0.9',
        'Sec-Fetch-Dest': 'empty',
        'Sec-Fetch-Mode': 'cors',
        'Sec-Fetch-Site': 'same-origin'
      }
      //inject cookie to headers
      await page.evaluate((cookie) => {
        document.cookie = `_tokenKey=${cookie[0].value}; path=/; domain=eu1.storj.io;`
      }, cookie)
      const openProject = (await page.$('text=Open Project')) ? true : false
      if (openProject) {
        await page.locator('text=Open Project').first().click()
      } else {
        await page.getByText('Create a Project').nth(1).click()
        await page.getByPlaceholder('Enter Project Name').click()
        await sleep(randTimeout(500, 1000))
        await page.getByPlaceholder('Enter Project Name').fill(projectName)
        const createProject = (await page.$('text=Create Project -->'),
        { timeout: 5000 })
          ? true
          : false
        if (!createProject) {
          await sleep(randTimeout(500, 1000))
          //press tab 3 times and press enter
          await page.keyboard.press('Tab')
          await sleep(randTimeout(500, 1000))
          await page.keyboard.press('Tab')
          await sleep(randTimeout(500, 1000))
          await page.keyboard.press('Tab')
          await sleep(randTimeout(500, 1000))
          await page.keyboard.press('Enter')
          await sleep(randTimeout(500, 1000))
        } else {
          try {
            await sleep(randTimeout(500, 1000))
            await page.getByText('Create Project -->').click()
          } catch (e) {
            await page.getByPlaceholder('Enter Project Name').click()
            await sleep(randTimeout(500, 1000))
            await page.getByPlaceholder('Enter Project Name').fill(projectName)
            await sleep(randTimeout(500, 1000))
            await page.getByText('Create Project -->').click()
          }
        }
      }
      let phasePraseDialogpage
      await page.waitForTimeout(1000)
      sleep(randTimeout(500, 1000))
      phasePraseDialogpage = (await page.$('text=Start with web browser', {
        timeout: 5000
      }))
        ? true
        : false
      if (phasePraseDialogpage) {
        await page.click('text=Continue in web')
      }
      const skipDialog = (await page.$('text=Cancel', {
        timeout: 5000
      }))
        ? true
        : false

      if (skipDialog) {
        await page.getByText('Cancel').click()
      }
      await page.waitForTimeout(500)
      const phasePraseDialog = (await page.$('text=Encryption Passphrase', {
        timeout: 5000
      }))
        ? true
        : false
      if (phasePraseDialog) {
        await page.locator('.mask__wrapper__container__close').click()
      }
      await sleep(randTimeout(500, 1000))
      await page.goto('https://eu1.storj.io/all-projects')
      await page.waitForTimeout(500)
      await page.locator('text=Open Project').first().click()
      await sleep(randTimeout(500, 1000))
      const skipButton = page.getByText('Skip', { timeout: 5000 })
        ? true
        : false
      if (skipButton) {
        try {
          await page.locator('.mask__wrapper__container__close').click()
        } catch (e) {}
      }
      phasePraseDialogpage = (await page.$('text=Start with web browser', {
        timeout: 5000
      }))
        ? true
        : false
      if (phasePraseDialogpage) {
        await page.goto('https://eu1.storj.io/all-projects')
        await page.waitForTimeout(500)
        await page.locator('text=Open Project').first().click()
      }
      await sleep(randTimeout(500, 1000))
      const accessButton = page.getByText('Access', { timeout: 5000 })
        ? true
        : false
      if (accessButton) {
        try {
          await page.locator('text=Access', { timeout: 5000 }).first().click()
        } catch (e) {
          await page.goto('https://eu1.storj.io/access-grants')
          await page.waitForTimeout(500)
        }
      }
      await sleep(1000)
      await page.reload()
      await page.waitForTimeout(500)
      await page.getByText('Create S3 Credentials').click()
      await page.getByPlaceholder('Input Access Name').click()
      await page.getByPlaceholder('Input Access Name').fill(accessName)
      await page
        .locator('div')
        .filter({ hasText: /^Access GrantS3 CredentialsCLI Access$/ })
        .locator('span')
        .first()
        .click()
      await page.getByText('Continue ->').click()
      await sleep(randTimeout(500, 1000))
      await page
        .locator('div')
        .filter({ hasText: /^I understand*/ })
        .locator('span')
        .click()
      await page.getByText('Continue ->').click()
      await sleep(1000)
      await page.getByText('Continue ->').click()
      await sleep(1000)
      await page.getByText('Create Access ->').click()
      await page.getByPlaceholder('Enter Encryption Passphrase').click()
      await page.getByPlaceholder('Enter Encryption Passphrase').fill(password)
      await page.getByText('Create Access ->').click()
      await sleep(1000)
      await page.getByText('Confirm').nth(1).click()
      await sleep(randTimeout(1000, 2000))
      //await page.getByText('Show Access Key').click()
      //await page.getByText('Show Secret Key').click()
      //await page.getByText('Show Endpoint').click()
      //locate p tag with class blured-container__wrap__text shown
      //wait until page.locator('.blured-container__wrap__text') appear
      await page.waitForSelector('.blured-container__wrap__text')
      const credentialLocation = page.locator('.blured-container__wrap__text')
      const accessGrant = await credentialLocation.first().textContent()
      await sleep(randTimeout(500, 1000))
      await page.getByText('Next', { exact: true }).click()
      const accessKey = await credentialLocation.nth(0).textContent()
      const secretKey = await credentialLocation.nth(1).textContent()
      const endpoint = await credentialLocation.nth(2).textContent()
      await page.close()
      await browser.close()

      const projectId = await axios
        .get('https://eu1.storj.io/api/v0/projects', {
          headers: headers,
          httpAgent: proxyAgent,
          httpsAgent: proxyAgent
        })
        .then((response) => {
          if (response.status == 200) {
            return response.data[0].id
          } else {
            console.log('Get project id failed')
          }
        })
      const setSessionTimeout = await axios
        .patch(
          'https://eu1.storj.io/api/v0/auth/account/settings',
          {
            sessionDuration: 2592000000000000
          },
          {
            headers: headers,
            httpAgent: proxyAgent,
            httpsAgent: proxyAgent
          }
        )
        .then((response) => {
          if (response.status == 200) {
            return response.data.sessionDuration
          } else {
            console.log('Set session timeout failed')
          }
        })
        .catch((error) => {
          console.log(error)
        })
      const accountCreatedAt = await axios
        .get(`https://eu1.storj.io/api/v0/auth/account`, {
          headers: headers,
          httpAgent: proxyAgent,
          httpsAgent: proxyAgent
        })
        .then((response) => {
          if (response.status == 200) {
            return response.data.createdAt
          } else {
            throw new Error('Get account created date failed')
          }
        })
      cookie = cookie[0].value
      let saveData = `${email}|${password}|${accessKey}|${secretKey}|${endpoint}|${accessGrant}|${projectId}|${cookie}|${accountCreatedAt}|${setSessionTimeout}`
      //save saveData to file data.txt
      fs.appendFile('fulldata.txt', `${saveData}\n`, (err) => {
        if (err) {
          console.log(err)
        }
      })

      verboseLog('SUCCESS', `${email}`)
      await browser.close()
      return {
        email: email,
        password: password,
        passPhrase: passPhrase,
        accessKey: accessKey,
        secretKey: secretKey,
        endpoint: endpoint,
        accessGrant: accessGrant,
        projectId: projectId,
        cookie: cookie,
        accountCreatedAt: accountCreatedAt,
        setSessionTimeout: setSessionTimeout
      }
    } catch (e) {
      await sleep(30000)
      await page.close()
      await browser.close()
      verboseLog('ERROR', `Error login dua ${email}`)
      console.log(e)
      return null
    }
  } catch (e) {
    verboseLog('ERROR', `Error login tiga ${email}`)
    await page.close()
    await browser.close()
    console.log(e)
    return null
  }
}

export async function submitStorj(data) {
  let { config, save } = data
  let email = null

  try {
    const submitUrl = new URL(`/storj/register`, `${config.main.baseUrl}`)
    const apiKey = config.main.chiaChunkApiKey
    submitUrl.searchParams.append('apiKey', apiKey)
    const submit = await axios.post(submitUrl.toString(), save)
    if (submit.data.success == true) {
      email = submit.data.storjResult.email
      verboseLog('INFO', `Success Submit ${email} to database`)
    }
  } catch (e) {
    verboseLog('ERROR', `Error submitting ${email} to database`)
    verboseLog('ERROR', e)
  }
}
