import {
  randTimeout,
  changeIp,
  parseConfig,
  parseProxy,
  completeSignup,
  getConfirmCode,
  generateData,
  sleep,
  getMailAddress,
  getConfirmUrl2,
  noCaptchaAiSolve,
  getnoCaptchaAiCredit,
  capSolverSolve,
  getCapSolverBalance,
  antiCaptchaSolve,
  getAntiCaptchaBalance,
  signUpStorj,
  loginGen,
  submitStorj,
  testConfig,
  verboseLog,
  resendCode
} from './function.js'
import fs from 'fs'
import path from 'path'
import { default as minimist } from 'minimist'
const __dirname = path.dirname(new URL(import.meta.url).pathname)

const argv = minimist(process.argv.slice(2))
const changeIpFlag = argv['changeip'] || false
const test = argv['test'] || false
const checkCredit = argv['checkCredit'] || false

const empass = argv['empass']
;(async () => {
  /*
  const timeNow = new Date().getTime()
  console.log(timeNow)

  
  let [emailAddress, password] = empass.split('|')
  const requestId = await resendCode(data, emailAddress, proxy, config)
  //get time utc now

  console.log(requestId)
  */

  const datainput =
    'calimeo@24hinbox.com|WfTO16EZtiLu|917e515a36505c4e406184cd5ed530c0'
  const requestId = datainput.split('|')[2]
  const code = '281711'
  const emailAddress = datainput.split('|')[0]
  const password = datainput.split('|')[1]
  /*
  const proxy = await parseProxy()
  const config = await parseConfig()
  const data = await generateData()
  
  const cookie = await completeSignup(
    generatedData,
    emailAddress,
    code,
    requestId,
    proxy
  )
  console.log(cookie)
  */
  const proxy = await parseProxy()
  const config = await parseConfig()
  const data = await generateData()
  const generatedData = {
    userAgent: data.userAgent,
    password: 'WfTO16EZtiLu',
    projectName: data.projectName,
    accessName: data.accessName,
    fullName: data.fullName
  }
  const cookie =
    'RMyU-GrlR8yYJRRJyi2JuQ==.YxGlGzTG-k4kCQXH7wENGWC4C7-QmaCCQDFngp6lMAQ='
  await loginGen(generatedData, proxy, cookie, emailAddress)
})()
