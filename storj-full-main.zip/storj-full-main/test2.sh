#!/usr/local/env bash

#seq inf | parallel -j 30 -n 'node solveCaptcha.js {}'

seq inf | parallel -j 30 'node solveCaptcha.js {}'
