import { parseConfig, genDataImpulse } from './parseConfig.js'
import { verboseLog, sleep } from './function.js'
import {
  signUpStorj,
  getMailAddress,
  getConfirmCode,
  completeSignup,
  generateData,
  loginGen,
  submitStorj
} from './signUp.js'
import { HttpsProxyAgent as HttpProxyAgent } from 'https-proxy-agent'
import axios from 'axios'

export async function solveCaptcha(data) {
  const solveCaptchaMap = {
    antiCaptchaApiKey: {
      func: antiCaptchaSolve,
      getCredit: getAntiCaptchaBalance
    },
    capSolverApiKey: { func: capSolverSolve, getCredit: getCapSolverBalance },
    twoCaptchaApiKey: { func: twoCaptchaSolve, getCredit: getTwoCaptchaCredit },
    capMonsterApiKey: { func: capMonsterSolve, getCredit: getCapMonsterBalance }
  }
  if (!data.emailAddress) {
    data.emailAddress = process.pid
  }
  const useSolver = data.config.main.useSolver
  const captchaResponse = await solveCaptchaMap[useSolver].func(data)
  return captchaResponse
}

export async function getCaptchaCredit(data) {
  const solveCaptchaMap = {
    antiCaptchaApiKey: {
      func: antiCaptchaSolve,
      getCredit: getAntiCaptchaBalance
    },
    capSolverApiKey: { func: capSolverSolve, getCredit: getCapSolverBalance },
    twoCaptchaApiKey: { func: twoCaptchaSolve, getCredit: getTwoCaptchaCredit },
    capMonsterApiKey: { func: capMonsterSolve, getCredit: getCapMonsterBalance }
  }
  const useSolver = data.config.main.useSolver
  const credit = await solveCaptchaMap[useSolver].getCredit(data)
  return credit
}

export async function getCapMonsterBalance(data) {
  const url = 'https://api.capmonster.cloud/getBalance'
  const apiKey = data.config.captchaApiKey.capMonsterApiKey
  const headers = {
    'Content-Type': 'application/json'
  }
  const body = {
    clientKey: apiKey
  }
  let balance = null
  try {
    const response = await axios.post(url, body, { headers: headers })
    balance = response.data.balance
  } catch (error) {
    verboseLog('ERROR', error)
    return null
  }
  if (balance == null || balance <= 0.001) {
    verboseLog('INFO', `capMonster balance not found`)
    return null
  }
  verboseLog('INFO', `capMonster balance: ${balance}`)
  return balance
}

export async function getAntiCaptchaBalance(data) {
  const url = 'https://api.anti-captcha.com/getBalance'
  const apiKey = data.config.captchaApiKey.antiCaptchaApiKey
  const headers = {
    'Content-Type': 'application/json'
  }
  const body = {
    clientKey: apiKey
  }
  let balance = null
  try {
    const response = await axios.post(url, body, { headers: headers })
    balance = response.data.balance
  } catch (error) {
    verboseLog('ERROR', error)
    return null
  }
  verboseLog('INFO', `antiCaptcha balance: ${balance}`)
  return balance
}

export async function getnoCaptchaAiCredit(data) {
  const apiKey = data.config.captchaApiKey.noCaptchaAiApiKey
  const url = 'https://manage.nocaptchaai.com/balance'
  const headers = {
    'Content-Type': 'application/json',
    apikey: apiKey
  }
  let balance = null
  try {
    const response = await axios.get(url, { headers: headers })
    balance = response.data.Subscription.remaining
    if (balance == null || balance <= 1) {
      verboseLog('INFO', `noCaptchaAi Subscription remaining not found`)
      return null
    }
  } catch (error) {
    verboseLog('ERROR', error)
    return null
  }
  verboseLog('INFO', `noCaptchaAi balance: ${balance}`)
  return balance
}

export async function getTwoCaptchaCredit(data) {
  const apiKey = data.config.captchaApiKey.twoCaptchaApiKey
  const url = 'https://api.2captcha.com/getBalance'
  const headers = {
    'Content-Type': 'application/json'
  }
  const body = {
    clientKey: apiKey
  }
  let balance = null
  try {
    const response = await axios.post(url, body, { headers: headers })
    balance = response.data.balance
  } catch (error) {
    verboseLog('ERROR', error)
    return null
  }
  verboseLog('INFO', `twoCaptcha balance: ${balance}`)
  return balance
}

export async function getCapSolverBalance(data) {
  const apiKey = data.config.captchaApiKey.capSolverApiKey
  const url = 'https://api.capsolver.com/getBalance'
  const headers = {
    'Content-Type': 'application/json'
  }
  const body = {
    clientKey: apiKey
  }
  let balance = null
  try {
    const response = await axios.post(url, body, { headers: headers })
    balance = response.data.balance
    if (balance == null || balance <= 0.001) {
      verboseLog('INFO', `capSolver balance not found`)
      return null
    }
  } catch (error) {
    verboseLog('ERROR', error)
    return null
  }
  verboseLog('INFO', `capSolver balance: ${balance}`)
  return balance
}

export async function antiCaptchaSolve(data) {
  const timerStart = performance.now()
  const { emailAddress, config } = data
  let proxy
  if (
    config.main.useDataImpulse === 'captcha' ||
    config.main.useDataImpulse === 'all'
  ) {
    const dataImpulseDetail = await genDataImpulse(data)
    proxy = dataImpulseDetail.proxy
    /*
    if (config.dataImpulse.useSticky) {
      verboseLog(
        'INFO',
        `${emailAddress} capSolver using proxy ${dataImpulseDetail.ipDetail.ip} Country : ${dataImpulseDetail.ipDetail.country}`
      )
    }
    */
  } else {
    proxy = config.proxy
  }
  const apiKey = data.config.captchaApiKey.antiCaptchaApiKey
  const url = 'https://api.anti-captcha.com/createTask'
  const urlResult = 'https://api.anti-captcha.com/getTaskResult'
  const headers = {
    'Content-Type': 'application/json'
  }
  const body = {
    clientKey: apiKey,
    task: {
      type: 'HCaptchaTask',
      isInvisible: true,
      websiteURL: config.main.websiteUrl,
      websiteKey: config.main.siteKey,
      proxyType: proxy.proxyType,
      proxyAddress: proxy.proxyHost,
      proxyPort: Number(proxy.proxyPort)
    }
  }
  if (proxy.proxyUser && proxy.proxyPass) {
    body.task.proxyLogin = proxy.proxyUser
    body.task.proxyPassword = proxy.proxyPass
  }
  let captchaResponse,
    taskId,
    errorId = null
  try {
    let response = await axios.post(url, body, { headers: headers })
    taskId = response.data.taskId
    errorId = response.data.errorId
    if (taskId == null || errorId !== 0) {
      verboseLog('ERROR', 'Error creating antiCaptcha Task')
      return null
    }
    verboseLog('INFO', `${emailAddress} antiCaptcha got taskId: ${taskId}`)
    const getResultBody = {
      clientKey: apiKey,
      taskId: taskId
    }
    while (!captchaResponse) {
      response = await axios.post(urlResult, getResultBody, {
        headers: headers
      })
      if (response.data.errorId !== 0) {
        verboseLog(
          'ERROR',
          `${emailAddress} Error getting antiCaptcha Response`
        )
        verboseLog('ERROR', response.data.errorDescription)
        return null
      }
      if (response.data.status === 'processing') {
        await sleep(3000)
        continue
      }

      captchaResponse = response.data.solution.gRecaptchaResponse
      if (captchaResponse) {
        break
      }

      await sleep(3000)
    }
    const shortResponse =
      captchaResponse.slice(0, 8) + '...' + captchaResponse.slice(-8)
    const timerEnd = performance.now()
    const totalTime = Math.floor((timerEnd - timerStart) / 1000)

    verboseLog(
      'NOTICE',
      `${emailAddress} | antiCaptcha Got captcha response ${shortResponse} in ${totalTime} seconds`
    )
    return captchaResponse
  } catch (error) {
    verboseLog('ERROR', error)
    return null
  }
}

export async function twoCaptchaSolve(data) {
  const timerStart = performance.now()
  const { emailAddress, config } = data
  let proxy
  if (
    config.main.useDataImpulse === 'captcha' ||
    config.main.useDataImpulse === 'all'
  ) {
    const dataImpulseDetail = await genDataImpulse(data)
    proxy = dataImpulseDetail.proxy
    /*
    if (config.dataImpulse.useSticky) {
      verboseLog(
        'INFO',
        `${emailAddress} 2Captcha using proxy ${dataImpulseDetail.ipDetail.ip} Country : ${dataImpulseDetail.ipDetail.country}`
      )
    }
    */
  } else {
    proxy = config.proxy
  }
  const apiKey = data.config.captchaApiKey.twoCaptchaApiKey
  const url = 'https://api.2captcha.com/createTask'
  const urlResult = 'https://api.2captcha.com/getTaskResult'
  const headers = {
    'Content-Type': 'application/json'
  }
  const body = {
    clientKey: apiKey,
    task: {
      type: 'HCaptchaTask',
      isInvisible: true,
      websiteKey: config.main.siteKey,
      websiteURL: config.main.websiteUrl,
      proxyType: proxy.proxyType,
      proxyAddress: proxy.proxyHost,
      proxyPort: Number(proxy.proxyPort),
      proxyLogin: proxy.proxyUser,
      proxyPassword: proxy.proxyPass
    }
  }
  /*
  let rqData = null
  try {
    const proxyAgent = new HttpProxyAgent(proxy.proxyFull)
    const rqUrl =
      'https://api.hcaptcha.com/checksiteconfig?host=eu1.storj.io&sitekey=c5df5852-2fd3-4b65-a6a7-6b35cab2f989&sc=1&swa=1&spst=1'
    const rq = await axios.get(rqUrl, {
      httpsAgent: proxyAgent
    })
    rqData = rq.data.c.req
  } catch (error) {
    null
  }
  console.log('rqdata', rqData)
  if (rqData) {
    body.task.enterprisePayload = { rqdata: rqData }
  }
  */
  let captchaResponse,
    taskId,
    errorId = null
  try {
    let response = await axios.post(url, body, { headers: headers })
    taskId = response.data.taskId
    errorId = response.data.errorId
    if (taskId == null || errorId !== 0) {
      verboseLog('ERROR', 'Error creating 2captcha Task')
      return null
    }
    verboseLog('INFO', `${emailAddress} 2Captcha got taskId: ${taskId}`)
    const getResultBody = {
      clientKey: apiKey,
      taskId: taskId
    }
    while (!captchaResponse) {
      response = await axios.post(urlResult, getResultBody, {
        headers: headers
      })
      if (response.data.errorId !== 0) {
        verboseLog('ERROR', `${emailAddress} Error getting 2captcha Response`)
        verboseLog('ERROR', response.data.errorDescription)
        return null
      }
      if (response.data.status === 'processing') {
        await sleep(3000)
        continue
      }

      captchaResponse = response.data.solution.gRecaptchaResponse
      if (captchaResponse) {
        break
      }

      await sleep(3000)
    }
    const shortResponse =
      captchaResponse.slice(0, 8) + '...' + captchaResponse.slice(-8)
    const timerEnd = performance.now()
    const totalTime = Math.floor((timerEnd - timerStart) / 1000)
    verboseLog(
      'NOTICE',
      `${emailAddress} | 2Captcha Got captcha response ${shortResponse} in ${totalTime} seconds`
    )
    return captchaResponse
  } catch (error) {
    verboseLog('ERROR', error)
    return null
  }
}

export async function capSolverSolve(data) {
  const timerStart = performance.now()
  const { emailAddress, config } = data
  let proxy
  if (
    config.main.useDataImpulse === 'captcha' ||
    config.main.useDataImpulse === 'all'
  ) {
    const dataImpulseDetail = await genDataImpulse(data)
    proxy = dataImpulseDetail.proxy
    /*
    if (config.dataImpulse.useSticky) {
      if (dataImpulseDetail.ipDetail.ip !== null) {
        verboseLog(
          'INFO',
          `${emailAddress} capSolver using proxy ${dataImpulseDetail.ipDetail.ip} Country : ${dataImpulseDetail.ipDetail.country}`
        )
      }
    }
    */
  } else {
    proxy = config.proxy
  }
  const apiKey = data.config.captchaApiKey.capSolverApiKey
  const url = 'https://api.capsolver.com/createTask'
  const urlResult = 'https://api.capsolver.com/getTaskResult'
  const headers = {
    'Content-Type': 'application/json'
  }
  const body = {
    clientKey: apiKey,
    task: {
      type: 'HCaptchaTask',
      isInvisible: true,
      websiteURL: config.main.websiteUrl,
      websiteKey: config.main.siteKey,
      proxy: proxy.proxyFull
    }
  }
  let captchaResponse,
    taskId,
    errorId = null
  try {
    let response = await axios.post(url, body, { headers: headers })
    taskId = response.data.taskId
    errorId = response.data.errorId
    if (taskId == null || errorId !== 0) {
      verboseLog('ERROR', 'Error creating capSolver Task')
      verboseLog('ERROR', response.data.errorDescription)
      return null
    }
    verboseLog('INFO', `${emailAddress} capSolver got taskId: ${taskId}`)
    const getResultBody = {
      clientKey: apiKey,
      taskId: taskId
    }
    while (!captchaResponse) {
      response = await axios.post(urlResult, getResultBody, {
        headers: headers
      })
      if (response.data.errorId !== 0) {
        verboseLog('ERROR', `${emailAddress} Error getting capSolver Response`)
        verboseLog('ERROR', response.data.errorDescription)
        return null
      }
      if (
        response.data.status === 'processing' ||
        response.data.status === 'idle'
      ) {
        await sleep(3000)
        continue
      }

      captchaResponse = response.data.solution.gRecaptchaResponse
      if (captchaResponse) {
        break
      }

      await sleep(3000)
    }
    const shortResponse =
      captchaResponse.slice(0, 8) + '...' + captchaResponse.slice(-8)
    const timerEnd = performance.now()
    const totalTime = Math.floor((timerEnd - timerStart) / 1000)
    verboseLog(
      'NOTICE',
      `${emailAddress} | capSolver Got captcha response ${shortResponse} in ${totalTime} seconds`
    )
    return captchaResponse
  } catch (error) {
    verboseLog('ERROR', 'error creating capSolver Task')
    verboseLog('ERROR', error)
    return null
  }
}
export async function capMonsterSolve(data) {
  const timerStart = performance.now()
  const { emailAddress, config } = data
  let proxy
  if (
    config.main.useDataImpulse === 'captcha' ||
    config.main.useDataImpulse === 'all'
  ) {
    const dataImpulseDetail = await genDataImpulse(data)
    proxy = dataImpulseDetail.proxy
    /*
    if (config.dataImpulse.useSticky) {
      verboseLog(
        'INFO',
        `${emailAddress} capSolver using proxy ${dataImpulseDetail.ipDetail.ip} Country : ${dataImpulseDetail.ipDetail.country}`
      )
    }
    */
  } else {
    proxy = config.proxy
  }
  const apiKey = data.config.captchaApiKey.capMonsterApiKey
  const url = 'https://api.capmonster.cloud/createTask'
  const urlResult = 'https://api.capmonster.cloud/getTaskResult'
  const headers = {
    'Content-Type': 'application/json'
  }
  const body = {
    clientKey: apiKey,
    task: {
      type: 'HCaptchaTask',
      isInvisible: true,
      websiteURL: config.main.websiteUrl,
      websiteKey: config.main.siteKey,
      proxyType: proxy.proxyType,
      proxyAddress: proxy.proxyHost,
      proxyPort: Number(proxy.proxyPort)
    }
  }

  if (proxy.proxyUser && proxy.proxyPass) {
    body.task.proxyLogin = proxy.proxyUser
    body.task.proxyPassword = proxy.proxyPass
  }
  let captchaResponse,
    taskId,
    errorId = null
  try {
    let response = await axios.post(url, body, { headers: headers })
    taskId = response.data.taskId
    errorId = response.data.errorId
    if (taskId == null || errorId !== 0) {
      verboseLog('ERROR', 'Error creating capMonster Task')
      verboseLog('ERROR', response.data.errorDescription)
      return null
    }
    verboseLog('INFO', `${emailAddress} capMonster got taskId: ${taskId}`)
    const getResultBody = {
      clientKey: apiKey,
      taskId: taskId
    }
    while (!captchaResponse) {
      response = await axios.post(urlResult, getResultBody, {
        headers: headers
      })
      if (response.data.errorId !== 0) {
        verboseLog('ERROR', `${emailAddress} Error getting capMonster Response`)
        verboseLog('ERROR', response.data.errorDescription)
        return null
      }
      if (response.data.status === 'processing') {
        await sleep(3000)
        continue
      }

      captchaResponse = response.data.solution.gRecaptchaResponse
      if (captchaResponse) {
        break
      }

      await sleep(3000)
    }
    const shortResponse =
      captchaResponse.slice(0, 8) + '...' + captchaResponse.slice(-8)
    const timerEnd = performance.now()
    const totalTime = Math.floor((timerEnd - timerStart) / 1000)
    verboseLog(
      'NOTICE',
      `${emailAddress} | capMonster Got captcha response ${shortResponse} in ${totalTime} seconds`
    )
    return captchaResponse
  } catch (error) {
    verboseLog('ERROR', error)
    return null
  }
}

async function test() {
  const requestId = Math.floor(Math.random() * 10000000)
  const dataSignUp = await generateData()

  return { requestId, dataSignUp }
}

;(async () => {
  const data = {
    config: await parseConfig()
  }
  let credit
  while (!credit) {
    credit = await getCaptchaCredit(data)
    if (credit) {
      break
    }
    verboseLog('INFO', 'No credit found, sleep for 1 hour')
    await sleep(3600000)
  }
  data.captchaResponse = await solveCaptcha(data)
  if (!data.captchaResponse) {
    process.exit(1)
  }

  data.emailAddress = null
  while (!data.emailAddress) {
    data.emailAddress = await getMailAddress(data)
  }

  const { requestId, dataSignUp } = await signUpStorj(data)
  data.requestId = requestId
  data.dataSignUp = dataSignUp
  if (!data.requestId) {
    process.exit(1)
  }
  await sleep(3000)
  data.code = await getConfirmCode(data)
  for (let i = 0; i < 5; i++) {
    if (data.code) {
      break
    }
    await sleep(3000)
    data.code = await getConfirmCode(data)
  }
  if (!data.code) {
    process.exit(1)
  }
  data.cookie = await completeSignup(data)
  if (!data.cookie) {
    process.exit(1)
  }

  for (let i = 0; i < 5; i++) {
    data.save = await loginGen(data)
    if (data.save) {
      break
    }
    await sleep(3000)
  }

  if (!data.save) {
    process.exit(1)
  }
  await submitStorj(data)
  process.exit(0)
})()
