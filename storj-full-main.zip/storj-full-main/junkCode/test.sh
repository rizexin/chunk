#!/usr/bin/env bash

max=50

seq 1 $max | parallel -j 10 --joblog log.txt node solveCaptcha.js
