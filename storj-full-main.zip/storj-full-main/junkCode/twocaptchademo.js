import {
  randTimeout,
  changeIp,
  parseConfig,
  parseProxy,
  completeSignup,
  getConfirmCode,
  generateData,
  sleep,
  getMailAddress,
  getConfirmUrl2,
  noCaptchaAiSolve,
  getnoCaptchaAiCredit,
  capSolverSolve,
  getCapSolverBalance,
  antiCaptchaSolve,
  getAntiCaptchaBalance,
  twoCaptchaSolve,
  getTwoCaptchaCredit,
  signUpStorj,
  loginGen,
  submitStorj,
  testConfig,
  verboseLog
} from '../function.js'
import fs from 'fs'
import path from 'path'
import { default as minimist } from 'minimist'
const __dirname = path.dirname(new URL(import.meta.url).pathname)

const argv = minimist(process.argv.slice(2))
const changeIpFlag = argv['changeip'] || false
const test = argv['test'] || false
const checkCredit = argv['checkCredit'] || false

;(async () => {
  const proxy = await parseProxy()
  const config = await parseConfig()
  const emailAddress = 'ilyas@gmail.com'
  let captchaResponse
  const useSolverMapping = {
    noCaptchaAiApiKey: {
      func: noCaptchaAiSolve,
      getCredit: getnoCaptchaAiCredit
    },
    capSolverApiKey: { func: capSolverSolve, getCredit: getCapSolverBalance },
    antiCaptchaApiKey: {
      func: antiCaptchaSolve,
      getCredit: getAntiCaptchaBalance
    },
    twoCaptchaApiKey: {
      func: twoCaptchaSolve,
      getCredit: getTwoCaptchaCredit
    }
  }
  verboseLog('INFO', `Getting captcha response for ${emailAddress}`)
  for (let i = 0; i < 5; i++) {
    //verboseLog(
    // 'INFO',
    //`Getting captcha response for ${emailAddress} try ${i}`
    //)
    captchaResponse = await useSolverMapping[config.useSolver].func(
      config,
      proxy,
      emailAddress
    )
    if (captchaResponse != null) {
      verboseLog('SUCCESS', `Captcha response success for ${emailAddress}`)
      break
    }
    if (i == 4) {
      verboseLog('ERROR', 'Captcha not solved, exiting...')
      process.exit(1)
    }
    verboseLog('INFO', 'Captcha not solved, retrying...')
    await sleep(1000)
  }
  process.exit(0)
})()
