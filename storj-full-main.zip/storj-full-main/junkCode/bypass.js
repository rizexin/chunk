import { chromium } from 'playwright'
import {
  randTimeout,
  changeIp,
  parseConfig,
  parseProxy,
  completeSignup,
  getConfirmCode,
  generateData,
  sleep,
  getMailAddress,
  getConfirmUrl2,
  noCaptchaAiSolve,
  getnoCaptchaAiCredit,
  capSolverSolve,
  getCapSolverBalance,
  antiCaptchaSolve,
  getAntiCaptchaBalance,
  signUpStorj,
  loginGen,
  submitStorj,
  testConfig,
  verboseLog
} from '../function.js'
import fs from 'fs'
import path from 'path'
import { default as minimist } from 'minimist'
const __dirname = path.dirname(new URL(import.meta.url).pathname)

const argv = minimist(process.argv.slice(2))
const changeIpFlag = argv['changeip'] || false
const test = argv['test'] || false
const checkCredit = argv['checkCredit'] || false
const hcaptchaCookie =
  'H8bSKr9pOa+O1t+t+PTXYsws/9ua7ukt4arg2nlG3YMclzyLU8AyBRdynKjwuzDpT89jOzD6xLq4cRGGCq0KV/6G6T8sExBxUaIjEcSTBknCjP7C1dKJvo004umrKX5XxpgNr/bwyFAZI511VRSVGJZWaeODKje8QK6M2rVK7/WCou0VfoTGAkJ9uMCU/uUh97q/YJkdX5x22cqxnrgYo40/VmX2tGiOvRv9ZVgbYwLIYbwA1KT9Gqs3pW3IBchUBHNOdf2BbxSoP2jjHcaee68UJ7xXtvrPhBNpMUQXvP8kwjCqvIL/Am4vA5qLkLp05nj/FB1os9ac94DZ7o+tzcuPP7sxfGJGCa05upbIschN8FLbxovBGMkm4XEdyIdoq8T46iyxFvgL1K5RG22l1ymYdJINoLuEQUDv/rmI45kqQicUTE+rY85Gz/nW1oIU3d8Bvir9DHPyBCjupXyWwZizvwt/9wW3KFLaPwl2SYszBLCOoeabUZbbwjlWzEgJCmLF+ARZL9uD43c2i9OctUE6tfAtT6z2U8gVr/+rmSmCsKfe+ardlMw0DjKLWA3q+cyJlhMSwLzecAJ/h1SXqpKs3RvB5ZqMCjt3GkBVw/VfWRF2KlDyN+JPWJaQW4UXovyQ+7lzxj3mts6tB66VgvCgNA4GratPA93KtsHSh23g1zTqRmhUCLe4Z0tC6lPDa0/YVF+wO2mIIn8LaymZv/lJBylaa7IPuqgd3LD5W1EV1iYCGp4BxBsWwvXPgDi30WBK3WFbK/3Cg/8gTcIqH+PEuzAr2NvAysE3efFTUhBwE+scXnhrYLcE278m6aiWV7mBlkJMdQOnFaduaeCzCYmovGO12NqqFebjgfLXjZiuIaz2eSUH7uBY3Wb+2Jej3jphu/48VBDjB9aXscXWzty8cau0ztWigqCcqnDMLY2/8iCK9ha73jkLfzmotVe0w+o1Xj+MTwn6Dp4IpIcsIIGrcnTnAbutF4E5Sq9BpjxfeX/v5S2fZZu89MN6vN/eHbCiYydAHwJCpwk/wBqbwUV8+kh4p8hQLooos2KZ09R76FdRZltwHQbYdVqxO0nW+Vqn5oxrEXEG5o9J'

;(async () => {
  //clearup directory /userdata
  const dir = './userdata'
  if (fs.existsSync(dir)) {
    fs.rmdirSync(dir, { recursive: true })
  }
  fs.mkdirSync(dir)

  const proxy = await parseProxy()
  const config = await parseConfig()
  const data = await generateData()
  //const emailAddress = await getMailAddress(proxy.proxyFull
  const browser = await chromium.launchPersistentContext('./userdata', {
    headless: false,
    proxy: {
      server: proxy.proxyType + '://' + proxy.proxyHost + ':' + proxy.proxyPort,
      username: proxy.user,
      password: proxy.pass
    },
    ignoreHTTPSErrors: true
  })
  await browser.addCookies([
    {
      name: 'hc_accessibility',
      value: hcaptchaCookie,
      domain: '.hcaptcha.com',
      path: '/',
      expires: -1,
      httpOnly: false,
      secure: true,
      sameSite: 'None'
    },
    {
      name: 'session',
      value: '74cf2547-d52e-4c76-988e-2cb6db6683da',
      domain: '.hcaptcha.com',
      path: '/',
      expires: -1,
      httpOnly: false,
      secure: true,
      sameSite: 'None'
    }
  ])
  const page = await browser.newPage()
  await page.goto('https://2captcha.com/demo/hcaptcha')
  await page.waitForTimeout(100000)
})()
