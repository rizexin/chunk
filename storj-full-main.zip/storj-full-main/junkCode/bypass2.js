import { chromium } from 'playwright'
import {
  randTimeout,
  changeIp,
  parseConfig,
  parseProxy,
  completeSignup,
  getConfirmCode,
  generateData,
  sleep,
  getMailAddress,
  getConfirmUrl2,
  noCaptchaAiSolve,
  getnoCaptchaAiCredit,
  capSolverSolve,
  getCapSolverBalance,
  antiCaptchaSolve,
  getAntiCaptchaBalance,
  signUpStorj,
  loginGen,
  submitStorj,
  testConfig,
  verboseLog
} from '../function.js'
import fs from 'fs'
import path from 'path'
import { default as minimist } from 'minimist'
import { request } from 'http'
const __dirname = path.dirname(new URL(import.meta.url).pathname)

const argv = minimist(process.argv.slice(2))
const changeIpFlag = argv['changeip'] || false
const test = argv['test'] || false
const checkCredit = argv['checkCredit'] || false
const hcaptchaCookie =
  'iB6UMaeWKFFtcJlNaAqzosbAeF+kwlyr+f6rkTS/8LVea6XQQJNpV8SDRAW7SPJgYe0+UABSaNIh4iEXjJxxSl5+xV2qUub7BU970EwD8mBeAOtTNUby9VVqWUhb/OTYTGE7JKeHV7Hqs2Y4rxgWZXXPNEYt+j7/DdjA7/CGpcCCJqpJLa4S0rODmze2N+igKrwkbTWyBMsclePvGRWmK2sfnoC2CGGsyM2TtdF2l4HG8VGGQYhSn2GREWdyClU6GX4CFjxEub/7urXQ/dBAXfm5Gu79rtZvberYP0BZGbwY1jPvNHHgv62AHZ/JORfBbGzfS627XRsnKW/nZWMolaFXWK+5r5egVSj2NSDL2+eICHo/3ddQyVqXzkWE1H8bvgqrBom+tRwRnn8IXQJLsTfxh+HJZSKCUNU5J/fozF2BHWbMOxRmtqUd8OCE4l7OuBmbHlwAf1rYrgfH9D1mhjdnt1C6QPrSW50uNLA8KadiLb1xTOJ/Qp26wT65RftxS753aYrD0Pk0oIcRiweTIrMMyCAlkT6Ol5P+Zj9+ur90qNGM/uJM9NabiswsoZz5owC0VO8GtIHYcWQqOmwLZero8iGs02z44zNNkYQO0b/Jhe1YMHlCSCNqV1pCJi0884R7iEGjSfoV+xgeKIWWAHDbeNuoeJDPuIncyNZiklsa5OhH3It+WqL3pR9HZhl7Q6Jx4dnrYvnQuJFew5xRxsg4PF7rNmyuKJu98vAPqu8tEgsgPrmjq272Ppu15zeBuWEBIiFc0CsOGmleqnMAL7Q43wAzc8f1MHHneIpOtg+gQt+YF27piGYXhxA1ILHDkVxr/8PxUAjpAS0MnHbdPdeoX1sUQEE5HSJFNWPkKHqciWSrNVa1YDGpknqWq7MRIe3n3m7QncYUeg5C5Qnr8kPHNQQfQ7rKP+qXpUpe8RVpyYqoU994LmiXB9iIpc7RWlQzPbfgQdLazk0v14ZsPv/okAqHZMXEDz6Tfa0V/s2VMkxkWqFhvqG6QCryxfa3IqHl7m34bRFlNpY90NXNA16gx0IQsD7Y75uWKX44im8/DgTpZsRP8vOgYzF/O8u14dxTcG988HeijckrBMiTec2wYwDkJEW4'

;(async () => {
  while (true) {
    //clearup directory /userdata
    const dir = './userdata'
    if (fs.existsSync(dir)) {
      fs.rmSync(dir, { recursive: true })
    }
    fs.mkdirSync(dir)

    const proxy = await parseProxy()
    const config = await parseConfig()
    const data = await generateData()
    let emailAddress
    while (
      emailAddress == null ||
      emailAddress == '' ||
      emailAddress == ' ' ||
      emailAddress == undefined
    ) {
      emailAddress = await getMailAddress(proxy.otherProxy)
    }
    const user = emailAddress.split('@')[0]
    fs.mkdirSync(`${dir}/${user}`)
    const browser = await chromium.launchPersistentContext(`${dir}/${user}`, {
      headless: false,
      proxy: {
        server:
          proxy.proxyType + '://' + proxy.proxyHost + ':' + proxy.proxyPort,
        username: proxy.user,
        password: proxy.pass
      },
      ignoreHTTPSErrors: true,
      userAgent: data.userAgent
    })
    await browser.addCookies([
      {
        name: 'hc_accessibility',
        value: hcaptchaCookie,
        domain: '.hcaptcha.com',
        path: '/',
        expires: -1,
        httpOnly: false,
        secure: true,
        sameSite: 'None'
      }
    ])
    const page = await browser.newPage()
    await page.goto('https://eu1.storj.io/signup')
    await page.waitForTimeout(3000)
    try {
      await page.getByText('Personal').click()
    } catch (e) {
      verboseLog('ERROR', 'Signup button not found, exiting...')
      await page.close()
      await browser.close()
      continue
    }
    await page.getByPlaceholder('Your Name').click()
    await page.getByPlaceholder('Your Name').fill(data.fullName)
    await page.getByPlaceholder('email@example.com').click()
    await page.getByPlaceholder('email@example.com').fill(emailAddress)
    await page.getByPlaceholder('Enter Password').click()
    await page.getByPlaceholder('Enter Password').fill(data.password)
    await page.getByPlaceholder('Retype Password').fill(data.password)
    await page.locator('.checkmark').click()
    await sleep(3000)
    await page.waitForTimeout(3000)
    let requestId
    let failedCaptcha
    // Listen for all requests
    page.on('response', async (response) => {
      if (
        response.status() !== 200 &&
        response.url().includes('api.hcaptcha.com')
      ) {
        verboseLog('ERROR', 'Captcha not solved, exiting...')
        failedCaptcha = true
      }
    })
    if (failedCaptcha) {
      await page.close()
      await browser.close()
      continue
    }
    const requestIdPromise = new Promise((resolve) => {
      page.on('response', async (response) => {
        if (response.url() === 'https://eu1.storj.io/api/v0/auth/register') {
          requestId = response.headers()['x-request-id']
          resolve()
        }
      })
    })
    // Then perform the click action
    let failedSignup

    for (let i = 0; i < 6; i++) {
      try {
        const startButton = await page
          .waitForSelector('text=Get Started', { timeout: 1000 })
          .catch(() => null)

        if (startButton) {
          try {
            await startButton.click({ timeout: 1000 })
          } catch (e) {}
          await sleep(3000)
        } else {
          break
        }
        if (i == 5) {
          verboseLog('ERROR', 'fail to signup, exiting...')
          failedSignup = true
        }
      } catch (e) {
        verboseLog('ERROR', 'Signup button not found, exiting...')
        console.log(e)
      }
    }

    if (failedSignup) {
      await page.close()
      await browser.close()
      continue
    }
    await requestIdPromise
    for (let i = 0; i < 6; i++) {
      if (requestId != null) {
        break
      }
      await sleep(2000)
      if (i == 5) {
        verboseLog('ERROR', 'Signup failed, exiting...')
        failedSignup = true
      }
    }
    if (failedSignup) {
      await page.close()
      await browser.close()
      process.exit(1)
    }
    const checkInbox = (await page.getByRole('heading', {
      name: 'Check your inbox'
    }))
      ? true
      : false
    if (checkInbox) {
      await page.close()
      await browser.close()
    }
    fs.appendFile(
      'dataSignup.txt',
      `${emailAddress}|${data.password}|${requestId}\n`,
      (err) => {
        if (err) {
          console.log(err)
        }
      }
    )
    verboseLog(
      'SUCCESS',
      `Sign up success for ${emailAddress} with requestId: ${requestId}`
    )
    await sleep(300)
  }
})()
