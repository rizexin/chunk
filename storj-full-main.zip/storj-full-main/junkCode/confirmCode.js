import { chromium } from 'playwright'
import net from 'net'
import dns from 'dns'
import { SocksProxyAgent } from 'socks-proxy-agent'
import pojectnamegenerator from 'project-name-generator'
import { default as ConfigParser } from 'configparser'
import { faker } from '@faker-js/faker'
import axios from 'axios'
import path from 'path'
import fs from 'fs'
import chalk, { backgroundColorNames } from 'chalk'
import * as cheerio from 'cheerio'
import { Performance } from 'perf_hooks'
import { HttpsProxyAgent as HttpProxyAgent } from 'https-proxy-agent'
const __dirname = path.dirname(new URL(import.meta.url).pathname)

import {
  parseConfig,
  parseProxy,
  sleep,
  signUpStorj,
  getAntiCaptchaBalance,
  antiCaptchaSolve,
  verboseLog,
  isIpAddress,
  getMailAddress,
  getConfirmUrl2,
  parseDataImpulse,
  generateData,
  noCaptchaAiSolve,
  getnoCaptchaAiCredit,
  capSolverSolve,
  getCapSolverBalance
} from './function.js'

export async function getConfirmCode(emailAddress, proxy) {
  const user = emailAddress.split('@')[0]
  const domain = emailAddress.split('@')[1]
  const { protocol } = new URL(proxy.proxyFull)
  let proxyAgent = null
  if (protocol === 'socks5:') {
    proxyAgent = new SocksProxyAgent(proxy.proxyFull)
  } else if (protocol === 'http:') {
    proxyAgent = new HttpProxyAgent(proxy.proxyFull)
  }
  const mainCookie =
    '_ga=GA1.2.747718287.1611551159; _gid=GA1.2.786119622.1615220663; ' +
    'embx=%5B%22dogeanjay00%40gxmer.com%22%2C%22ayamanjay%40bedul.net' +
    '%22%2C%22ngawurnajayy%40plitur.com%22%2C%222ionel.radu.9826%40coronagg.com' +
    '%22%2C%221ahmad.pop%40hustletussle.com%22%2C%22hmohame%40acmta.com' +
    '%22%2C%22qsmar%40ucombinator.com%22%2C%22zlimon.shuvo29%40furnitt.com' +
    '%22%2C%22odmsal1%40wikuiz.com%22%5D; _gat=1; ' +
    `surl=${domain}%2F${user}`
  const mainUrl = 'https://generator.email/inbox5/'
  const mainHeaders = {
    Cookie: mainCookie
  }
  try {
    const inbox = await axios.get(mainUrl, {
      headers: mainHeaders,
      httpAgent: proxyAgent,
      httpsAgent: proxyAgent
    })
    const inboxData = cheerio.load(inbox.data)
    const emailTable = inboxData('#email-table')
    function getCode(data) {
      try {
        const code = data
          .find(
            'h1[style="font-family: Helvetica, sans-serif; font-weight: 500; line-height: 1.2; mso-line-height-alt: 14px; margin: 20px 0"]'
          )
          .text()
          .trim()
        return code
      } catch (err) {
        verboseLog('ERROR', `Error getting confirm code: ${err}`)
      }
    }
    let code
    if (emailTable.length == 0) {
      verboseLog('ERROR', `${emailAddress} inbox not found`)
      return null
    } else {
      let inboxUrl = emailTable.find('a').attr('href')
      if (!inboxUrl.includes(user)) {
        code = getCode(emailTable)
      } else {
        const inboxPath = inboxUrl.split('/').pop()
        const inboxCookie = `embx=%5B%22${user}%40${domain}%22%5D; surl=${domain}%2F${user}%2F${inboxPath}`
        const inboxHeaders = {
          Cookie: inboxCookie
        }
        inboxUrl = `https://generator.email/inbox2/`
        const inboxData2 = await axios.get(inboxUrl, {
          headers: inboxHeaders,
          httpAgent: proxyAgent,
          httpsAgent: proxyAgent
        })
        const inboxData2Data = cheerio.load(inboxData2.data)
        const inboxEmailTable = inboxData2Data('#email-table')
        code = getCode(inboxEmailTable)
      }
      return code
    }
  } catch (err) {
    verboseLog('ERROR', `Error getting confirm code: ${err}`)
  }
}
