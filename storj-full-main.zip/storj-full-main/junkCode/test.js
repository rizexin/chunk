import chalk from 'chalk'
import axios from 'axios'
import { HttpProxyAgent } from 'http-proxy-agent'
import { HttpsProxyAgent } from 'https-proxy-agent'
import net from 'net'
import dns from 'dns'
import { SocksProxyAgent } from 'socks-proxy-agent'
import {
  parseConfig,
  parseProxy,
  sleep,
  signUpStorj,
  getAntiCaptchaBalance,
  antiCaptchaSolve,
  verboseLog,
  isIpAddress,
  getMailAddress,
  getConfirmUrl2,
  parseDataImpulse,
  generateData,
  noCaptchaAiSolve,
  getnoCaptchaAiCredit,
  capSolverSolve,
  getCapSolverBalance
} from '../function.js'
import cheerio from 'cheerio'
import { chromium, request } from 'playwright'
;(async () => {
  /*
    const dataImpulseConfig = await parseDataImpulse()
    console.log(dataImpulseConfig)
    /*
    const config = await parseConfig()
    const proxy = await parseProxy()
    const { userName, pass, hostname, port } = proxy
    const { protocol } = new URL(proxy.proxyFull)
    let proxyAgent = null
    if (protocol === 'socks5:') {
      proxyAgent = new SocksProxyAgent(proxy.proxyFull)
    } else if (protocol === 'http:') {
      proxyAgent = new HttpsProxyAgent(proxy.proxyFull)
    } else if (protocol === 'https:') {
      proxyAgent = new HttpsProxyAgent(proxy.proxyFull)
    }
    console.log(protocol)
    const ipAddress = await axios
      .get('https://ipinfo.io/ip', {
        httpAgent: proxyAgent,
        httpsAgent: proxyAgent
      })
      .then((res) => res.data)
    console.log(ipAddress)
    /*
    const browser = await chromium.launch({
      headless: false,
      proxy: {
        server: proxy.proxyFull,
        username: user,
        password: pass
      }
    })
    const context = await browser.newContext()
    const page = await context.newPage()
    await page.goto(
      'https://eu1.storj.io/activation?token=eyJpZCI6IjIzNDczMmVlLTQ1YzQtNDk1Mi05ZWJjLTY3NzI4ZjFhMTM5MiIsImVtYWlsIjoibGVvdnVzaGtpbmFAYWRzZmFmZ2FzLmNsb3VkIiwiZXhwaXJlcyI6IjIwMjMtMTItMDFUMDA6NDk6MDAuMzEzNzU0NzY1WiJ9Cg==.i26gsL2rGswmQic35Yhzv4kojxIEPouQyYp1C5Tw6Hc='
    )
    await page.waitForTimeout(1000)
    await sleep(15000)
    await browser.close()
    console.log(ipAddress2)
    
    const emailAddress = 'alicastepanova@oxvps.us'
    const user = emailAddress.split('@')[0]
    const domain = emailAddress.split('@')[1]
    const cookie =
      '_ga=GA1.2.747718287.1611551159; _gid=GA1.2.786119622.1615220663; ' +
      'embx=%5B%22dogeanjay00%40gxmer.com%22%2C%22ayamanjay%40bedul.net' +
      '%22%2C%22ngawurnajayy%40plitur.com%22%2C%222ionel.radu.9826%40coronagg.com' +
      '%22%2C%221ahmad.pop%40hustletussle.com%22%2C%22hmohame%40acmta.com' +
      '%22%2C%22qsmar%40ucombinator.com%22%2C%22zlimon.shuvo29%40furnitt.com' +
      '%22%2C%22odmsal1%40wikuiz.com%22%5D; _gat=1; ' +
      `surl=${domain}%2F${user}`
    const url = 'http://generator.email/inbox5/'
    const headers = {
      Cookie: cookie
    }
    console.log(headers)
    const response = await axios.get(url, {
      headers: headers,
      httpAgent: proxyAgent
      //httpsAgent: proxyAgent
    })
    console.log(response.data)
    */
})()
;(async () => {
  const proxy = await parseProxy()
  console.log(proxy)
  /*
  const config = await parseConfig()
  const data = await generateData()
  const emailAddress = 'claudiomg@ulcemail.eu'
  const confirmUrl = await getConfirmUrl3(emailAddress, proxy)
  /*
  let emailAddress
  while (
    emailAddress == null ||
    emailAddress == '' ||
    emailAddress == ' ' ||
    emailAddress == undefined
  ) {
    emailAddress = await getMailAddress(proxy.proxyFull)
  }
  let captchaResponse = null
  let i = 0
  const useSolverMapping = {
    noCaptchaAiApiKey: {
      func: noCaptchaAiSolve,
      getCredit: getnoCaptchaAiCredit
    },
    capSolverApiKey: { func: capSolverSolve, getCredit: getCapSolverBalance },
    antiCaptchaApiKey: {
      func: antiCaptchaSolve,
      getCredit: getAntiCaptchaBalance
    }
  }
  verboseLog('INFO', `Getting captcha response for ${emailAddress}`)
  for (let i = 0; i < 5; i++) {
    //verboseLog(
    // 'INFO',
    //`Getting captcha response for ${emailAddress} try ${i}`
    //)
    captchaResponse = await useSolverMapping[config.useSolver].func(
      config,
      proxy,
      emailAddress
    )
    if (captchaResponse != null) {
      verboseLog('SUCCESS', `Captcha response success for ${emailAddress}`)
      break
    }
    if (i == 4) {
      verboseLog('ERROR', 'Captcha not solved, exiting...')
      process.exit(1)
    }
    verboseLog('INFO', 'Captcha not solved, retrying...')
    await sleep(1000)
  }
  //console.log(captchaResponse)
  console.log(data)
  console.log(emailAddress)
  await signUpStorj(data, emailAddress, proxy, captchaResponse)
  */
})()
