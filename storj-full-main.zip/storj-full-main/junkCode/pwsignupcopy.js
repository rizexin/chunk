import { chromium, request } from 'playwright-extra'
import StealthPlugin from 'puppeteer-extra-plugin-stealth'
import {
  randTimeout,
  changeIp,
  parseConfig,
  parseProxy,
  completeSignup,
  getConfirmCode,
  generateData,
  sleep,
  getMailAddress,
  getConfirmUrl2,
  noCaptchaAiSolve,
  getnoCaptchaAiCredit,
  capSolverSolve,
  getCapSolverBalance,
  antiCaptchaSolve,
  getAntiCaptchaBalance,
  signUpStorj,
  loginGen,
  submitStorj,
  testConfig,
  verboseLog
} from '../function.js'
import fs from 'fs'
import path from 'path'
import { default as minimist } from 'minimist'
import { base } from '@faker-js/faker'
const __dirname = path.dirname(new URL(import.meta.url).pathname)

export async function signUp(
  generatedData,
  mailAddress,
  proxy,
  captchaResponse
) {
  const password = generatedData.password
  const fullName = generatedData.fullName

  const headers = {
    Host: 'eu1.storj.io',
    Connection: 'keep-alive',
    'Content-Type': 'application/json',
    Accept: '*/*',
    Origin: 'https://eu1.storj.io',
    Referer: 'https://eu1.storj.io/signup',
    'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'en-US,en;q=0.9',
    'Sec-Fetch-Dest': 'empty',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Site': 'same-origin'
  }
  const url = 'https://eu1.storj.io/api/v0/auth/register'
  const data = {
    secret: '',
    password: password,
    fullName: fullName,
    shortName: '',
    email: mailAddress,
    partner: '',
    partnerId: '',
    isProfessional: false,
    position: '',
    companyName: '',
    employeeCount: '',
    haveSalesContact: false,
    signupPromoCode: '',
    captchaResponse: captchaResponse
  }
  chromium.use(StealthPlugin())
  const user = mailAddress.split('@')[0]
  const dir = './userdata'
  const profileDir = path.join(dir, user)
  const browser = await chromium.launchPersistentContext(profileDir, {
    headless: false,
    proxy: {
      server: proxy.proxyType + '://' + proxy.proxyHost + ':' + proxy.proxyPort,
      username: proxy.user,
      password: proxy.pass
    }
  })
  const page = await browser.newPage()
  try {
    await page.goto('https://eu1.storj.io/login', {
      waitUntil: 'domcontentloaded'
    })
  } catch (error) {
    console.log('Navigation timed out, but continuing execution...')
  }
  const argument = {
    url: url,
    headers: headers,
    data: data
  }
  let signUp
  try {
    signUp = await page.evaluate(async (data) => {
      const response = await fetch('/api/v0/auth/register', {
        method: 'POST',
        headers: data.headers,
        body: JSON.stringify(data.data)
      })
      if (response.status !== 200) {
        return null
      }
      return response.headers.get('x-request-id')
    }, argument)
  } catch (e) {
    console.log(e)
    return null
  }
  await browser.close()
  return signUp
}
