import { chromium } from 'playwright'
import {
  randTimeout,
  changeIp,
  parseConfig,
  parseProxy,
  completeSignup,
  getConfirmCode,
  generateData,
  sleep,
  getMailAddress,
  getConfirmUrl2,
  noCaptchaAiSolve,
  getnoCaptchaAiCredit,
  capSolverSolve,
  getCapSolverBalance,
  antiCaptchaSolve,
  getAntiCaptchaBalance,
  signUpStorj,
  loginGen,
  submitStorj,
  testConfig,
  verboseLog
} from '../function.js'
import fs from 'fs'
import path from 'path'
import { default as minimist } from 'minimist'
import { request } from 'http'
const __dirname = path.dirname(new URL(import.meta.url).pathname)

const argv = minimist(process.argv.slice(2))
const changeIpFlag = argv['changeip'] || false
const test = argv['test'] || false
const checkCredit = argv['checkCredit'] || false
const hcaptchaCookie =
  'Y8v26KW1X+Y47EToHtBh2G2LfHQTHqCb1bx9qJQvFgKCfHwThX0hsYpUbpUcrfN1RKNsz3K4RvjgS5fUeVOoYJyhbUBrmQWNVol3Pk+kPf4yXDevKlz3JQwPdYjFp4cGuQBMjMLtQ5HlgmVxlN8jfgtY6VTeLpSMtToJPqjxDxVMTreGtLASRye2n2adcAsvi2RKvcQ7Z5UuSv5LFDBWE5lbS1ZYYkVTzhfx3Z3HjPHIxqgi4J7uL3+i8OWa8kkHtmeKytc8K8A2eT91HGNWqJaitxqgWXA8+Ny24/dvM2LFtO/o2fF78WkaA+rEh0RVU5txvjRxb30hbdTOvRgSrHYMJqHInp0PRLHKgY5I/W9pa0kkvd3cD0HHOu1K5Fyi7kqitM28oDN+ZwmLbLZXxJJkSeq19Oec9fNivOGrgOhhvOxG8gvqwPEnqUtC7jwF9wrvFHGFzN9MNFKtM0+JEfMsx7oQ7wAVGLVoNevaGQvehs5PrWO6g/2OKC6CxeS9pXvxK+ArjRBAdwBL4UXnxXp7J/NwUwoFX+wXPv9MKESi5VbCUGrh9UtyLtDrJRS5Odes78iARHkfdjwK0VuoQGquyi3NFdXauTz72+KuCdJwzo3niXLyoJ+SJ3cQrfr7aE/WTMzJaR7PPWlugcUU+QDjLVbqVG5I82saWgW9GPWzKW51EJIsrI1j2D4NaQyoMeCHeHrryhP4R2rixNz3Lth3ty6c1irvzTowNY2LIk8CQ/JuQoq4pI7pm3xX8VBjWyFvSJeMUCb75XwYto6CCnkBYr37mIRgXnK1u2DMfNB/SGzzBkS9+EFBVPnydW0fwkJ98K7ljJIPxe4ABKUpy7IZ0FW57m/DckG0A4BJbVoUHL2/6oOqDnJDcd9L9N3WqrOL723XQE/+7ZSPomowehZgm1eNCVVk78Y9z4OC4Nq2u31DF0N3m/h2kp1+5iXvd3SIeg0MIIP9Iqsr1pIKLtPsv2RcD4jRp7/IhQAnfSETIcRsGuFwA2aVeDRPY53S+4AOLw9qdO8lvCixB3ZeDnzZBDCix8wSl20ebVqIHc6efwsxa3L7XdXrJ3p6fVnpjOUZcR0tzDM=cg3Ue/1KA3B1sBle'

;(async () => {
  while (true) {
    //clearup directory /userdata
    const dir = './userdata'
    if (fs.existsSync(dir)) {
      fs.rmSync(dir, { recursive: true })
    }
    fs.mkdirSync(dir)

    const proxy = await parseProxy()
    const config = await parseConfig()
    const data = await generateData()
    let emailAddress
    while (
      emailAddress == null ||
      emailAddress == '' ||
      emailAddress == ' ' ||
      emailAddress == undefined
    ) {
      emailAddress = await getMailAddress(proxy.otherProxy)
    }
    const user = emailAddress.split('@')[0]
    fs.mkdirSync(`${dir}/${user}`)
    const browser = await chromium.launchPersistentContext(`${dir}/${user}`, {
      headless: false,
      proxy: {
        server:
          proxy.proxyType + '://' + proxy.proxyHost + ':' + proxy.proxyPort,
        username: proxy.user,
        password: proxy.pass
      },
      ignoreHTTPSErrors: true,
      userAgent: data.userAgent
    })

    await browser.addCookies([
      {
        name: 'hc_accessibility',
        value: hcaptchaCookie,
        domain: '.hcaptcha.com',
        path: '/',
        expires: -1,
        httpOnly: false,
        secure: true,
        sameSite: 'None'
      }
    ])

    const page = await browser.newPage()
    await page.goto(
      'https://accounts.hcaptcha.com/verify_email/1c9374e6-e81b-4252-b742-d337601774c4'
    )
    await page.getByRole('button', { name: 'Set Cookie' }).click()
    await page.waitForTimeout(3000)
    await page.goto('https://eu1.storj.io/signup')
    await page.waitForTimeout(3000)
    try {
      await page.getByText('Personal').click()
    } catch (e) {
      verboseLog('ERROR', 'Signup button not found, exiting...')
      await page.close()
      await browser.close()
      continue
    }
    await page.getByPlaceholder('Your Name').click()
    await page.getByPlaceholder('Your Name').fill(data.fullName)
    await page.getByPlaceholder('email@example.com').click()
    await page.getByPlaceholder('email@example.com').fill(emailAddress)
    await page.getByPlaceholder('Enter Password').click()
    await page.getByPlaceholder('Enter Password').fill(data.password)
    await page.getByPlaceholder('Retype Password').fill(data.password)
    await page.locator('.checkmark').click()
    await sleep(3000)
    await page.waitForTimeout(3000)
    let requestId
    let failedCaptcha
    // Listen for all requests
    page.on('response', async (response) => {
      if (
        response.status() !== 200 &&
        response.url().includes('api.hcaptcha.com')
      ) {
        verboseLog('ERROR', 'Captcha not solved, exiting...')
        failedCaptcha = true
      }
    })
    if (failedCaptcha) {
      await page.close()
      await browser.close()
      continue
    }
    const requestIdPromise = new Promise((resolve) => {
      page.on('response', async (response) => {
        if (response.url() === 'https://eu1.storj.io/api/v0/auth/register') {
          requestId = response.headers()['x-request-id']
          resolve()
        }
      })
    })
    // Then perform the click action
    let failedSignup

    for (let i = 0; i < 6; i++) {
      try {
        const startButton = await page
          .waitForSelector('text=Get Started', { timeout: 1000 })
          .catch(() => null)

        if (startButton) {
          try {
            await startButton.click({ timeout: 1000 })
          } catch (e) {}
          await sleep(3000)
        } else {
          break
        }
        if (i == 5) {
          verboseLog('ERROR', 'fail to signup, exiting...')
          failedSignup = true
        }
      } catch (e) {
        verboseLog('ERROR', 'Signup button not found, exiting...')
        console.log(e)
      }
    }

    if (failedSignup) {
      await page.close()
      await browser.close()
      continue
    }
    await requestIdPromise
    for (let i = 0; i < 6; i++) {
      if (requestId != null) {
        break
      }
      await sleep(2000)
      if (i == 5) {
        verboseLog('ERROR', 'Signup failed, exiting...')
        failedSignup = true
      }
    }
    if (failedSignup) {
      await page.close()
      await browser.close()
      process.exit(1)
    }
    const checkInbox = (await page.getByRole('heading', {
      name: 'Check your inbox'
    }))
      ? true
      : false
    if (checkInbox) {
      await page.close()
      await browser.close()
    }
    fs.appendFile(
      'dataSignup.txt',
      `${emailAddress}|${data.password}|${requestId}\n`,
      (err) => {
        if (err) {
          console.log(err)
        }
      }
    )
    verboseLog(
      'SUCCESS',
      `Sign up success for ${emailAddress} with requestId: ${requestId}`
    )
    await sleep(300)
  }
})()
