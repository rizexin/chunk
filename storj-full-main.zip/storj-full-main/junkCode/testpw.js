import { chromium, request } from 'playwright-extra'
import StealthPlugin from 'puppeteer-extra-plugin-stealth'
import {
  randTimeout,
  changeIp,
  parseConfig,
  parseProxy,
  completeSignup,
  getConfirmCode,
  generateData,
  sleep,
  getMailAddress,
  getConfirmUrl2,
  noCaptchaAiSolve,
  getnoCaptchaAiCredit,
  capSolverSolve,
  getCapSolverBalance,
  antiCaptchaSolve,
  getAntiCaptchaBalance,
  signUpStorj,
  loginGen,
  submitStorj,
  testConfig,
  verboseLog
} from './function.js'
import fs from 'fs'
import path from 'path'
import { default as minimist } from 'minimist'
const __dirname = path.dirname(new URL(import.meta.url).pathname)

;(async () => {
  const proxy = await parseProxy()
  const data = {
    headers: {
      'Content-Type': 'application/json',
      sumber: 'lain'
    },
    data: {
      email: 'email@ilyas'
    }
  }
  chromium.use(StealthPlugin())
  const browser = await chromium.launch({
    headless: false
    //proxy: {
    // server: proxy.proxyType + '://' + proxy.proxyHost + ':' + proxy.proxyPort,
    //username: proxy.user,
    //password: proxy.pass
    // }
  })
  const page = await browser.newPage()
  await page.goto('http://localhost:4000/user')
  const response = await page.evaluate(async (data) => {
    const response = await fetch('/user/test', {
      method: 'POST',
      headers: data.headers,
      body: JSON.stringify(data.data)
    }).then((res) => {
      const cookie = res.headers.get('Set-Cookie')
      return cookie
    })
    return response
  }, data)

  await browser.close()
})()
