import {
  randTimeout,
  changeIp,
  parseConfig,
  parseProxy,
  generateData,
  sleep,
  getMailAddress,
  getConfirmUrl2,
  noCaptchaAiSolve,
  getnoCaptchaAiCredit,
  capSolverSolve,
  getCapSolverBalance,
  antiCaptchaSolve,
  getAntiCaptchaBalance,
  signUpStorj,
  loginGen,
  submitStorj,
  testConfig,
  verboseLog
} from './function.js'
import fs from 'fs'
import path from 'path'
import { default as minimist } from 'minimist'
const __dirname = path.dirname(new URL(import.meta.url).pathname)

const argv = minimist(process.argv.slice(2))
const changeIpFlag = argv['changeip'] || false
const test = argv['test'] || false
const checkCredit = argv['checkCredit'] || false

;(async () => {
  try {
    const proxy = await parseProxy()
    if (changeIpFlag) {
      await changeIp(proxy)
      await sleep(1000)
      return
    }

    const config = await parseConfig()
    if (test) {
      const testResult = await testConfig(config, proxy)
      if (testResult == 0) {
        process.exit(0)
      } else {
        process.exit(1)
      }
    }

    const data = await generateData()
    let emailAddress
    while (
      emailAddress == null ||
      emailAddress == '' ||
      emailAddress == ' ' ||
      emailAddress == undefined
    ) {
      emailAddress = await getMailAddress(proxy.proxyFull)
    }
    let captchaResponse = null
    let i = 0
    const useSolverMapping = {
      noCaptchaAiApiKey: {
        func: noCaptchaAiSolve,
        getCredit: getnoCaptchaAiCredit
      },
      capSolverApiKey: { func: capSolverSolve, getCredit: getCapSolverBalance },
      antiCaptchaApiKey: {
        func: antiCaptchaSolve,
        getCredit: getAntiCaptchaBalance
      }
    }
    verboseLog('INFO', `Getting captcha response for ${emailAddress}`)
    for (let i = 0; i < 5; i++) {
      //verboseLog(
      // 'INFO',
      //`Getting captcha response for ${emailAddress} try ${i}`
      //)
      captchaResponse = await useSolverMapping[config.useSolver].func(
        config,
        proxy,
        emailAddress
      )
      if (captchaResponse != null) {
        verboseLog('SUCCESS', `Captcha response success for ${emailAddress}`)
        break
      }
      if (i == 4) {
        verboseLog('ERROR', 'Captcha not solved, exiting...')
        process.exit(1)
      }
      verboseLog('INFO', 'Captcha not solved, retrying...')
      await sleep(1000)
    }

    await signUpStorj(data, emailAddress, proxy, captchaResponse)
    await sleep(1000)

    let confirmUrl = null
    for (let i = 0; i <= 2; i++) {
      confirmUrl = await getConfirmUrl2(emailAddress, proxy, {
        data,
        captchaResponse
      })
      if (confirmUrl != null) {
        break
      }

      if (i == 2) {
        verboseLog(
          'ERROR',
          `Confirm url not found for ${emailAddress}, exiting`
        )
        process.exit(1)
      }
      verboseLog(
        'ERROR',
        `Confirm url not found for ${emailAddress} , retrying...`
      )
    }
    //save data email|password|confirmUrl to file signup.txt
    fs.appendFile(
      'signup.txt',
      `${emailAddress}|${data.password}|${confirmUrl}\n`,
      (err) => {
        if (err) {
          console.log(err)
        }
      }
    )
    const dataUser = await loginGen(data, proxy, confirmUrl, emailAddress)
    if (dataUser) {
      await submitStorj(config, dataUser)
    }
    await process.exit(0)
  } catch (e) {
    await process.exit(1)
  }
})()
