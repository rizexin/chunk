import {
  randTimeout,
  changeIp,
  parseConfig,
  parseProxy,
  generateData,
  sleep,
  getMailAddress,
  getConfirmUrl2,
  noCaptchaAiSolve,
  getnoCaptchaAiCredit,
  capSolverSolve,
  getCapSolverBalance,
  antiCaptchaSolve,
  getAntiCaptchaBalance,
  twoCaptchaSolve,
  getTwoCaptchaCredit,
  signUpStorj,
  loginGen,
  submitStorj,
  testConfig,
  completeSignup,
  verboseLog,
  resendCode
} from '../function.js'
import { signUp } from './pwsignup.js'

import { getConfirmCode } from '../confirmCode.js'
import fs from 'fs'
import path from 'path'
import { default as minimist } from 'minimist'
const __dirname = path.dirname(new URL(import.meta.url).pathname)

const argv = minimist(process.argv.slice(2))
const changeIpFlag = argv['changeip'] || false
const test = argv['test'] || false
const checkCredit = argv['checkCredit'] || false

;(async () => {
  while (true) {
    try {
      const proxy = await parseProxy()
      if (changeIpFlag) {
        await changeIp(proxy)
        await sleep(1000)
        return
      }

      const config = await parseConfig()
      if (test) {
        const testResult = await testConfig(config, proxy)
        if (testResult == 0) {
          process.exit(0)
        } else {
          continue
        }
      }

      const data = await generateData()
      let emailAddress
      while (
        emailAddress == null ||
        emailAddress == '' ||
        emailAddress == ' ' ||
        emailAddress == undefined
      ) {
        emailAddress = await getMailAddress(proxy.proxyFull)
      }
      let captchaResponse = null
      let i = 0
      const useSolverMapping = {
        noCaptchaAiApiKey: {
          func: noCaptchaAiSolve,
          getCredit: getnoCaptchaAiCredit
        },
        capSolverApiKey: {
          func: capSolverSolve,
          getCredit: getCapSolverBalance
        },
        antiCaptchaApiKey: {
          func: antiCaptchaSolve,
          getCredit: getAntiCaptchaBalance
        },
        twoCaptchaApiKey: {
          func: twoCaptchaSolve,
          getCredit: getTwoCaptchaCredit
        }
      }
      verboseLog('INFO', `Getting captcha response for ${emailAddress}`)
      while (true) {
        captchaResponse = await useSolverMapping[config.useSolver].func(
          config,
          proxy,
          emailAddress
        )
        if (captchaResponse != null) {
          verboseLog('SUCCESS', `Captcha response success for ${emailAddress}`)
          break
        }
      }
      let requestId
      for (let i = 0; i < 5; i++) {
        requestId = await signUp(data, emailAddress, proxy, captchaResponse)
        console.log(`requestId: ${requestId}`)
        if (requestId != null) {
          break
        }
      }
      console.log(requestId)
      await sleep(1000)
      if (!requestId) {
        verboseLog('ERROR', 'Sign up failed, exiting...')
        continue
      }

      fs.appendFile(
        'dataSignup.txt',
        `${emailAddress}|${data.password}|${requestId}\n`,
        (err) => {
          if (err) {
            console.log(err)
          }
        }
      )
      console.log(`${emailAddress}|${data.password}|${requestId}`)
      /*
    let code
    for (let i = 0; i < 5; i++) {
      code = await getConfirmCode(emailAddress, proxy)
      if (code != null) {
        break
      }
      if (i == 4) {
        verboseLog('ERROR', 'Confirm code not found, exiting...')
        break
      }
      verboseLog('INFO', 'Confirm code not found, retrying...')
      await sleep(10000)
    }
    if (!code) {
      requestId = await resendCode(data, emailAddress, proxy)
      for (let i = 0; i < 5; i++) {
        code = await getConfirmCode(emailAddress, proxy)
        if (code != null) {
          break
        }
        if (i == 4) {
          verboseLog('ERROR', 'Confirm code not found, exiting...')
          continue
        }
        verboseLog('INFO', 'Confirm code not found, retrying...')
        await sleep(10000)
      }
    }
    if (!code) {
      verboseLog('ERROR', 'Confirm code not found, exiting...')
      continue
    }
    console.log(code)

    const cookie = await completeSignup(
      data,
      emailAddress,
      verifCode,
      requestId,
      proxy
    )
    console.log(cookie)

    const dataUser = await loginGen(data, proxy, cookie, emailAddress)
*/
    } catch (e) {
      console.log(e)
    }
  }
})()
